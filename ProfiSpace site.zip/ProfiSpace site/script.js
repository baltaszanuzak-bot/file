// ---------- Модель данных ----------
let currentUser = null;       // { name, role, rating, reviews, portfolio, id }
let orders = [];              // заказы
let responses = [];           // отклики (связь orderId + freelancer)
let deals = [];               // выбранные исполнители (сделки)
let messages = [];            // сообщения в чатах { orderId, sender, text, timestamp }

// Загрузка из localStorage
function loadData() {
    const storedUser = localStorage.getItem('fl_user');
    if (storedUser) currentUser = JSON.parse(storedUser);
    orders = JSON.parse(localStorage.getItem('fl_orders') || '[]');
    responses = JSON.parse(localStorage.getItem('fl_responses') || '[]');
    deals = JSON.parse(localStorage.getItem('fl_deals') || '[]');
    messages = JSON.parse(localStorage.getItem('fl_messages') || '[]');
}
function saveAll() {
    if (currentUser) localStorage.setItem('fl_user', JSON.stringify(currentUser));
    localStorage.setItem('fl_orders', JSON.stringify(orders));
    localStorage.setItem('fl_responses', JSON.stringify(responses));
    localStorage.setItem('fl_deals', JSON.stringify(deals));
    localStorage.setItem('fl_messages', JSON.stringify(messages));
}

// Генератор ID
function uid() { return Date.now() + '-' + Math.random().toString(36).substr(2, 6); }

// Добавить заказ
function createOrder(title, category, description, budget) {
    if (!currentUser || currentUser.role !== 'customer') return false;
    const newOrder = {
        id: uid(),
        title, category, description,
        budget: budget || 'договорная',
        customer: currentUser.name,
        customerId: currentUser.id,
        status: 'open',
        createdAt: new Date().toLocaleString(),
        chosenFreelancer: null,
        completed: false
    };
    orders.unshift(newOrder);
    saveAll();
    return true;
}

// Откликнуться на заказ
function addResponse(orderId, comment, price) {
    if (!currentUser || currentUser.role !== 'freelancer') return false;
    const order = orders.find(o => o.id === orderId);
    if (!order || order.status !== 'open') return false;
    const existing = responses.find(r => r.orderId === orderId && r.freelancerId === currentUser.id);
    if (existing) return false;
    responses.push({
        id: uid(),
        orderId,
        freelancerId: currentUser.id,
        freelancerName: currentUser.name,
        comment,
        price: price || order.budget,
        createdAt: new Date().toLocaleString()
    });
    saveAll();
    return true;
}

// Заказчик выбирает исполнителя (запускает сделку)
function selectFreelancer(orderId, freelancerId) {
    const order = orders.find(o => o.id === orderId);
    if (!order || order.customerId !== currentUser.id) return false;
    const resp = responses.find(r => r.orderId === orderId && r.freelancerId === freelancerId);
    if (!resp) return false;
    // создаём сделку
    deals.push({
        id: uid(),
        orderId,
        orderTitle: order.title,
        customerId: order.customerId,
        customerName: order.customer,
        freelancerId: freelancerId,
        freelancerName: resp.freelancerName,
        amount: resp.price,
        status: 'in_progress', // in_progress, completed, waiting_review
        createdAt: new Date().toLocaleString(),
        completedAt: null,
        customerReviewed: false,
        freelancerReviewed: false
    });
    order.status = 'in_progress';
    order.chosenFreelancer = freelancerId;
    saveAll();
    return true;
}

// Завершить сделку (заказчик подтверждает выполнение)
function completeDeal(dealId) {
    const deal = deals.find(d => d.id === dealId);
    if (!deal || deal.customerId !== currentUser.id) return false;
    deal.status = 'completed';
    deal.completedAt = new Date().toLocaleString();
    const order = orders.find(o => o.id === deal.orderId);
    if (order) order.status = 'completed';
    saveAll();
    return true;
}

// Оставить отзыв (после завершения)
function addReview(dealId, rating, text, forFreelancer = true) {
    const deal = deals.find(d => d.id === dealId);
    if (!deal) return false;
    const targetId = forFreelancer ? deal.freelancerId : deal.customerId;
    // ищем пользователя (в реальном БД, у нас только текущий, но для демо добавим в массив пользователей?)
    // упрощённо: сохраняем отзыв в специальное поле текущего пользователя? Но отзывы должны быть видны в профиле.
    // Для простоты сохраним отзывы в отдельный массив reviews и при рендере профиля будем собирать рейтинг
    // Добавим глобальный массив reviews
    if (!window.reviews) window.reviews = [];
    window.reviews.push({
        id: uid(),
        targetId,
        authorId: currentUser.id,
        authorName: currentUser.name,
        rating,
        text,
        createdAt: new Date().toLocaleString()
    });
    if (forFreelancer) deal.customerReviewed = true;
    else deal.freelancerReviewed = true;
    saveAll();
    return true;
}

// Отправить сообщение
function sendMessage(orderId, text) {
    if (!currentUser) return false;
    messages.push({
        id: uid(),
        orderId,
        senderId: currentUser.id,
        senderName: currentUser.name,
        text,
        timestamp: new Date().toLocaleString()
    });
    saveAll();
    return true;
}

// Получить сообщения для заказа
function getMessages(orderId) {
    return messages.filter(m => m.orderId === orderId).sort((a,b) => a.timestamp.localeCompare(b.timestamp));
}

// Подсчёт рейтинга пользователя
function getUserRating(userId) {
    if (!window.reviews) window.reviews = [];
    const userReviews = window.reviews.filter(r => r.targetId === userId);
    if (userReviews.length === 0) return 0;
    const sum = userReviews.reduce((acc, r) => acc + r.rating, 0);
    return (sum / userReviews.length).toFixed(1);
}

// Получить заказы, где пользователь является заказчиком
function getMyOrders() {
    return orders.filter(o => o.customerId === currentUser.id);
}
// Получить заказы, на которые пользователь откликнулся
function getMyResponses() {
    return responses.filter(r => r.freelancerId === currentUser.id);
}
// Получить сделки, где участвует пользователь
function getMyDeals() {
    return deals.filter(d => d.customerId === currentUser.id || d.freelancerId === currentUser.id);
}

// ---------- UI Рендеринг ----------
let activeTab = 'projects';
let currentSearch = '';
let currentCategory = '';

function render() {
    if (!currentUser) return;
    renderProfile();
    renderProjectsList();
    renderMyOrders();
    renderMyResponses();
    renderDeals();
}
function renderProfile() {
    const profileCard = document.getElementById('profileCard');
    const rating = getUserRating(currentUser.id);
    profileCard.innerHTML = `
        <div class="avatar"><i class="fas fa-user-circle"></i></div>
        <div class="profile-name">${escapeHtml(currentUser.name)}</div>
        <div class="profile-role">${currentUser.role === 'customer' ? 'Заказчик' : 'Фрилансер'}</div>
        <div class="rating"><i class="fas fa-star"></i> ${rating} (${window.reviews?.filter(r=>r.targetId===currentUser.id).length || 0})</div>
    `;
}
function renderProjectsList() {
    const container = document.getElementById('projectsList');
    let filtered = orders.filter(o => o.status === 'open');
    if (currentSearch) filtered = filtered.filter(o => o.title.toLowerCase().includes(currentSearch.toLowerCase()));
    if (currentCategory) filtered = filtered.filter(o => o.category === currentCategory);
    if (filtered.length === 0) {
        container.innerHTML = '<div class="empty-state">Нет открытых заказов</div>';
        return;
    }
    container.innerHTML = filtered.map(order => `
        <div class="order-card">
            <div class="order-title">${escapeHtml(order.title)}</div>
            <div class="order-meta">
                <span><i class="fas fa-tag"></i> ${order.category}</span>
                <span class="budget"><i class="fas fa-coins"></i> ${order.budget}</span>
                <span><i class="fas fa-user"></i> ${order.customer}</span>
            </div>
            <div class="description">${escapeHtml(order.description)}</div>
            <div class="card-actions">
                ${currentUser.role === 'freelancer' ? `<button class="btn-outline btn-sm" data-order="${order.id}" data-action="response">Откликнуться</button>` : ''}
            </div>
        </div>
    `).join('');
    document.querySelectorAll('[data-action="response"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const orderId = btn.getAttribute('data-order');
            openResponseModal(orderId);
        });
    });
}
function renderMyOrders() {
    const container = document.getElementById('myOrdersList');
    if (currentUser.role !== 'customer') {
        container.innerHTML = '<div class="empty-state">Вы заказчик — здесь будут ваши заказы</div>';
        return;
    }
    const myOrders = getMyOrders();
    if (myOrders.length === 0) { container.innerHTML = '<div class="empty-state">У вас пока нет заказов</div>'; return; }
    container.innerHTML = myOrders.map(order => `
        <div class="order-card">
            <div class="order-title">${escapeHtml(order.title)}</div>
            <div class="order-meta"><span>Статус: ${order.status === 'open' ? 'Открыт' : order.status === 'in_progress' ? 'В работе' : 'Завершён'}</span></div>
            <div class="description">${escapeHtml(order.description)}</div>
            ${order.status === 'open' ? `<div class="card-actions"><button class="btn-outline" data-order="${order.id}" data-action="showResponses">Посмотреть отклики (${responses.filter(r=>r.orderId===order.id).length})</button></div>` : ''}
        </div>
    `).join('');
    document.querySelectorAll('[data-action="showResponses"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const orderId = btn.getAttribute('data-order');
            showResponsesList(orderId);
        });
    });
}
function renderMyResponses() {
    const container = document.getElementById('myResponsesList');
    if (currentUser.role !== 'freelancer') {
        container.innerHTML = '<div class="empty-state">Вы фрилансер — здесь будут ваши отклики</div>';
        return;
    }
    const myResponses = getMyResponses();
    if (myResponses.length === 0) { container.innerHTML = '<div class="empty-state">Вы ещё не откликались на заказы</div>'; return; }
    container.innerHTML = myResponses.map(resp => {
        const order = orders.find(o => o.id === resp.orderId);
        return `<div class="order-card">
            <div class="order-title">${order ? order.title : 'Удалённый заказ'}</div>
            <div>Ваш отклик: ${escapeHtml(resp.comment)}</div>
            <div class="order-meta">Цена: ${resp.price} | Статус: ${order?.status === 'open' ? 'Ожидает выбора' : order?.status === 'in_progress' ? 'Выбран другой исполнитель' : 'Завершён'}</div>
        </div>`;
    }).join('');
}
function renderDeals() {
    const container = document.getElementById('dealsList');
    const myDeals = getMyDeals();
    if (myDeals.length === 0) { container.innerHTML = '<div class="empty-state">Активных сделок нет</div>'; return; }
    container.innerHTML = myDeals.map(deal => `
        <div class="order-card">
            <div class="order-title">${escapeHtml(deal.orderTitle)}</div>
            <div>Стороны: ${deal.customerName} — ${deal.freelancerName}</div>
            <div>Сумма: ${deal.amount}</div>
            <div>Статус: ${deal.status === 'in_progress' ? 'В работе' : 'Завершён'}</div>
            <div class="card-actions">
                ${deal.status === 'in_progress' && deal.customerId === currentUser.id ? `<button class="btn-outline" data-deal="${deal.id}" data-action="complete">Подтвердить выполнение</button>` : ''}
                ${deal.status === 'completed' && ((deal.customerId === currentUser.id && !deal.customerReviewed) || (deal.freelancerId === currentUser.id && !deal.freelancerReviewed)) ? `<button class="btn-outline" data-deal="${deal.id}" data-action="review">Оставить отзыв</button>` : ''}
                <button class="btn-outline" data-deal="${deal.id}" data-action="chat">Чат</button>
            </div>
        </div>
    `).join('');
    document.querySelectorAll('[data-action="complete"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const dealId = btn.getAttribute('data-deal');
            if (confirm('Подтвердить выполнение заказа и перевести оплату?')) {
                completeDeal(dealId);
                render();
            }
        });
    });
    document.querySelectorAll('[data-action="review"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const dealId = btn.getAttribute('data-deal');
            openReviewModal(dealId);
        });
    });
    document.querySelectorAll('[data-action="chat"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const dealId = btn.getAttribute('data-deal');
            const deal = deals.find(d => d.id === dealId);
            if (deal) openChatModal(deal.orderId, deal.orderTitle);
        });
    });
}
function showResponsesList(orderId) {
    const respList = responses.filter(r => r.orderId === orderId);
    if (respList.length === 0) { alert('Нет откликов'); return; }
    let msg = 'Отклики:\n';
    respList.forEach(r => {
        msg += `${r.freelancerName}: ${r.comment} (цена: ${r.price})\n`;
    });
    const choice = prompt(msg + '\nВведите ID фрилансера, чтобы выбрать исполнителя:\n' + respList.map(r=>`${r.freelancerName} (ID: ${r.freelancerId})`).join('\n'));
    if (choice) {
        const selected = respList.find(r => r.freelancerId === choice);
        if (selected && confirm(`Назначить ${selected.freelancerName} исполнителем?`)) {
            selectFreelancer(orderId, selected.freelancerId);
            render();
        }
    }
}
function openResponseModal(orderId) {
    const modal = document.getElementById('responseModal');
    const order = orders.find(o => o.id === orderId);
    document.getElementById('responseOrderTitle').innerText = order.title;
    modal.style.display = 'flex';
    modal.dataset.orderId = orderId;
}
function openChatModal(orderId, title) {
    const modal = document.getElementById('chatModal');
    document.getElementById('chatOrderTitle').innerText = title;
    modal.dataset.orderId = orderId;
    modal.style.display = 'flex';
    renderChatMessages(orderId);
}
function renderChatMessages(orderId) {
    const container = document.getElementById('chatMessages');
    const msgs = getMessages(orderId);
    container.innerHTML = msgs.map(m => `<div class="message ${m.senderId === currentUser.id ? 'own' : ''}"><strong>${escapeHtml(m.senderName)}</strong><br>${escapeHtml(m.text)}<br><small>${m.timestamp}</small></div>`).join('');
}
function openReviewModal(dealId) {
    const deal = deals.find(d => d.id === dealId);
    const modal = document.getElementById('reviewModal');
    const targetName = deal.freelancerId === currentUser.id ? deal.customerName : deal.freelancerName;
    document.getElementById('reviewFreelancerName').innerText = targetName;
    modal.dataset.dealId = dealId;
    modal.style.display = 'flex';
}
// helpers
function escapeHtml(str) { if(!str) return ''; return str.replace(/[&<>]/g, function(m){if(m==='&') return '&amp;'; if(m==='<') return '&lt;'; if(m==='>') return '&gt;'; return m;}); }

// Инициализация событий
document.addEventListener('DOMContentLoaded', () => {
    loadData();
    if (!window.reviews) window.reviews = JSON.parse(localStorage.getItem('fl_reviews') || '[]');
    const saveReviews = () => localStorage.setItem('fl_reviews', JSON.stringify(window.reviews));
    const origSave = saveAll;
    window.saveAll = function() { origSave(); saveReviews(); };
    saveAll = window.saveAll;

    const loginBtn = document.getElementById('loginBtn');
    const authModal = document.getElementById('authModal');
    const closeBtns = document.querySelectorAll('.modal .close');
    loginBtn.onclick = () => authModal.style.display = 'flex';
    closeBtns.forEach(btn => btn.onclick = () => btn.closest('.modal').style.display = 'none');

    const roleBtns = document.querySelectorAll('.role-btn');
    let selectedRole = 'customer';
    roleBtns.forEach(btn => {
        btn.onclick = () => { roleBtns.forEach(b=>b.classList.remove('active')); btn.classList.add('active'); selectedRole = btn.dataset.role; };
    });
    document.getElementById('authSubmitBtn').onclick = () => {
        const name = document.getElementById('authName').value.trim();
        if (!name) return alert('Введите имя');
        currentUser = { id: uid(), name, role: selectedRole, rating: 0 };
        saveAll();
        authModal.style.display = 'none';
        document.getElementById('mainContent').style.display = 'block';
        document.getElementById('userStatus').innerHTML = `<i class="fas fa-user"></i> ${escapeHtml(name)} (${selectedRole === 'customer' ? 'Заказчик' : 'Фрилансер'})`;
        render();
    };
    document.getElementById('createOrderBtn').onclick = () => {
        if (currentUser.role !== 'customer') return alert('Только заказчики могут создавать заказы');
        document.getElementById('createOrderModal').style.display = 'flex';
    };
    document.getElementById('submitOrderBtn').onclick = () => {
        const title = document.getElementById('orderTitle').value;
        const cat = document.getElementById('orderCategory').value;
        const desc = document.getElementById('orderDescription').value;
        const budget = document.getElementById('orderBudget').value;
        if (!title || !desc) return alert('Заполните название и описание');
        createOrder(title, cat, desc, budget);
        document.getElementById('createOrderModal').style.display = 'none';
        render();
    };
    document.getElementById('submitResponseBtn').onclick = () => {
        const modal = document.getElementById('responseModal');
        const orderId = modal.dataset.orderId;
        const comment = document.getElementById('responseComment').value;
        const price = document.getElementById('responsePrice').value;
        if (!comment) return alert('Напишите текст отклика');
        addResponse(orderId, comment, price);
        modal.style.display = 'none';
        render();
    };
    document.getElementById('sendMessageBtn').onclick = () => {
        const modal = document.getElementById('chatModal');
        const orderId = modal.dataset.orderId;
        const text = document.getElementById('chatInput').value;
        if (!text) return;
        sendMessage(orderId, text);
        document.getElementById('chatInput').value = '';
        renderChatMessages(orderId);
    };
    document.getElementById('submitReviewBtn').onclick = () => {
        const modal = document.getElementById('reviewModal');
        const dealId = modal.dataset.dealId;
        const rating = document.querySelector('.rating-stars span.active')?.dataset.rating || 5;
        const text = document.getElementById('reviewText').value;
        const deal = deals.find(d => d.id === dealId);
        const forFreelancer = (deal.freelancerId === currentUser.id ? false : true);
        addReview(dealId, parseInt(rating), text, forFreelancer);
        modal.style.display = 'none';
        render();
    };
    // звёзды
    document.querySelectorAll('.rating-stars span').forEach(star => {
        star.onclick = () => {
            document.querySelectorAll('.rating-stars span').forEach(s=>s.classList.remove('active'));
            star.classList.add('active');
            let val = parseInt(star.dataset.rating);
            let prev = star.previousElementSibling;
            while(prev) { prev.classList.add('active'); prev = prev.previousElementSibling; }
        };
    });
    // навигация
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.onclick = () => {
            document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active'));
            btn.classList.add('active');
            const tab = btn.dataset.tab;
            document.querySelectorAll('.tab-content').forEach(t=>t.classList.remove('active'));
            if (tab === 'projects') document.getElementById('projectsTab').classList.add('active');
            else if (tab === 'myOrders') document.getElementById('myOrdersTab').classList.add('active');
            else if (tab === 'myResponses') document.getElementById('myResponsesTab').classList.add('active');
            else if (tab === 'deals') document.getElementById('dealsTab').classList.add('active');
            render();
        };
    });
    document.getElementById('searchOrders').addEventListener('input', (e) => { currentSearch = e.target.value; renderProjectsList(); });
    document.getElementById('categoryFilter').addEventListener('change', (e) => { currentCategory = e.target.value; renderProjectsList(); });
});