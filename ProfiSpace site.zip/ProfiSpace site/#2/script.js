// ---------- Модель данных ----------
let currentUser = null;
let orders = [];
let responses = [];
let deals = [];
let messages = [];

function loadData() {
    const storedUser = localStorage.getItem('fl_user');
    if (storedUser) currentUser = JSON.parse(storedUser);
    orders    = JSON.parse(localStorage.getItem('fl_orders')    || '[]');
    responses = JSON.parse(localStorage.getItem('fl_responses') || '[]');
    deals     = JSON.parse(localStorage.getItem('fl_deals')     || '[]');
    messages  = JSON.parse(localStorage.getItem('fl_messages')  || '[]');
}

function saveAll() {
    if (currentUser) localStorage.setItem('fl_user', JSON.stringify(currentUser));
    localStorage.setItem('fl_orders',    JSON.stringify(orders));
    localStorage.setItem('fl_responses', JSON.stringify(responses));
    localStorage.setItem('fl_deals',     JSON.stringify(deals));
    localStorage.setItem('fl_messages',  JSON.stringify(messages));
    localStorage.setItem('fl_reviews',   JSON.stringify(window.reviews || []));
}

function uid() { return Date.now() + '-' + Math.random().toString(36).substr(2, 6); }

function createOrder(title, category, description, budget) {
    if (!currentUser || currentUser.role !== 'customer') return false;
    orders.unshift({
        id: uid(), title, category, description,
        budget: budget || 'договорная',
        customer: currentUser.name,
        customerId: currentUser.id,
        status: 'open',
        createdAt: new Date().toLocaleString(),
        chosenFreelancer: null,
        completed: false
    });
    saveAll(); return true;
}

function addResponse(orderId, comment, price) {
    if (!currentUser || currentUser.role !== 'freelancer') return false;
    const order = orders.find(o => o.id === orderId);
    if (!order || order.status !== 'open') return false;
    if (responses.find(r => r.orderId === orderId && r.freelancerId === currentUser.id)) return false;
    responses.push({
        id: uid(), orderId,
        freelancerId: currentUser.id,
        freelancerName: currentUser.name,
        comment,
        price: price || order.budget,
        createdAt: new Date().toLocaleString()
    });
    saveAll(); return true;
}

function selectFreelancer(orderId, freelancerId) {
    const order = orders.find(o => o.id === orderId);
    if (!order || order.customerId !== currentUser.id) return false;
    const resp = responses.find(r => r.orderId === orderId && r.freelancerId === freelancerId);
    if (!resp) return false;
    deals.push({
        id: uid(), orderId,
        orderTitle: order.title,
        customerId: order.customerId,
        customerName: order.customer,
        freelancerId,
        freelancerName: resp.freelancerName,
        amount: resp.price,
        status: 'in_progress',
        createdAt: new Date().toLocaleString(),
        completedAt: null,
        customerReviewed: false,
        freelancerReviewed: false
    });
    order.status = 'in_progress';
    order.chosenFreelancer = freelancerId;
    saveAll(); return true;
}

function completeDeal(dealId) {
    const deal = deals.find(d => d.id === dealId);
    if (!deal || deal.customerId !== currentUser.id) return false;
    deal.status = 'completed';
    deal.completedAt = new Date().toLocaleString();
    const order = orders.find(o => o.id === deal.orderId);
    if (order) order.status = 'completed';
    saveAll(); return true;
}

function addReview(dealId, rating, text, forFreelancer = true) {
    const deal = deals.find(d => d.id === dealId);
    if (!deal) return false;
    const targetId = forFreelancer ? deal.freelancerId : deal.customerId;
    if (!window.reviews) window.reviews = [];
    window.reviews.push({ id: uid(), targetId, authorId: currentUser.id, authorName: currentUser.name, rating, text, createdAt: new Date().toLocaleString() });
    if (forFreelancer) deal.customerReviewed = true;
    else deal.freelancerReviewed = true;
    saveAll(); return true;
}

function sendMessage(orderId, text) {
    if (!currentUser) return false;
    messages.push({ id: uid(), orderId, senderId: currentUser.id, senderName: currentUser.name, text, timestamp: new Date().toLocaleString() });
    saveAll(); return true;
}

function getMessages(orderId) {
    return messages.filter(m => m.orderId === orderId);
}

function getUserRating(userId) {
    if (!window.reviews) window.reviews = [];
    const r = window.reviews.filter(r => r.targetId === userId);
    if (!r.length) return null;
    return (r.reduce((a, x) => a + x.rating, 0) / r.length).toFixed(1);
}

function getMyOrders()    { return orders.filter(o => o.customerId === currentUser.id); }
function getMyResponses() { return responses.filter(r => r.freelancerId === currentUser.id); }
function getMyDeals()     { return deals.filter(d => d.customerId === currentUser.id || d.freelancerId === currentUser.id); }

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

// ---------- Toast ----------
function showToast(msg, type = 'success') {
    const t = document.getElementById('toast');
    t.className = `toast ${type} show`;
    t.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${msg}`;
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.remove('show'), 3000);
}

// ---------- Modal helpers ----------
function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }

// ---------- Render ----------
let currentSearch = '';
let currentCategory = '';

function render() {
    if (!currentUser) return;
    renderProfile();
    renderProjectsList();
    renderMyOrders();
    renderMyResponses();
    renderDeals();
}

function renderProfile() {
    const rating = getUserRating(currentUser.id);
    const reviewCount = (window.reviews || []).filter(r => r.targetId === currentUser.id).length;
    const isCustomer = currentUser.role === 'customer';
    document.getElementById('profileCard').innerHTML = `
        <div class="avatar-wrap"><i class="fas fa-user"></i></div>
        <div class="profile-name">${escapeHtml(currentUser.name)}</div>
        <div class="profile-badge ${isCustomer ? 'badge-customer' : 'badge-freelancer'}">
            <i class="fas fa-${isCustomer ? 'building' : 'laptop-code'}"></i>
            ${isCustomer ? 'Заказчик' : 'Фрилансер'}
        </div>
        ${rating ? `<div class="profile-rating">★ ${rating} <span>(${reviewCount} отз.)</span></div>` : `<div class="profile-rating"><span style="color:var(--text-muted);font-size:0.78rem">Нет отзывов</span></div>`}
    `;
    const us = document.getElementById('userStatus');
    us.className = 'user-status logged-in';
    us.innerHTML = `<i class="fas fa-circle-dot pulse"></i> <strong>${escapeHtml(currentUser.name)}</strong>`;
}

function statusLabel(s) {
    if (s === 'open')        return '<span class="status-badge status-open">● Открыт</span>';
    if (s === 'in_progress') return '<span class="status-badge status-progress">● В работе</span>';
    return '<span class="status-badge status-done">✓ Завершён</span>';
}

function categoryIcon(cat) {
    const icons = {
        'Веб-разработка': 'fa-code',
        'Дизайн': 'fa-pen-ruler',
        'Маркетинг': 'fa-chart-line',
        'Мобильные приложения': 'fa-mobile-screen',
        'Копирайтинг': 'fa-feather'
    };
    return icons[cat] || 'fa-briefcase';
}

function renderProjectsList() {
    const container = document.getElementById('projectsList');
    let filtered = orders.filter(o => o.status === 'open');
    if (currentSearch)   filtered = filtered.filter(o => o.title.toLowerCase().includes(currentSearch.toLowerCase()));
    if (currentCategory) filtered = filtered.filter(o => o.category === currentCategory);
    if (!filtered.length) {
        container.innerHTML = `<div class="empty-state"><div class="empty-icon"><i class="fas fa-inbox"></i></div><p>Нет открытых заказов</p></div>`;
        return;
    }
    const alreadyResponded = new Set(responses.filter(r => r.freelancerId === currentUser?.id).map(r => r.orderId));
    container.innerHTML = filtered.map(order => `
        <div class="order-card">
            <div class="order-category-tag"><i class="fas ${categoryIcon(order.category)}"></i> ${order.category}</div>
            <div class="order-title">${escapeHtml(order.title)}</div>
            <div class="order-desc">${escapeHtml(order.description)}</div>
            <div class="order-footer">
                <div class="order-meta-row">
                    <span class="budget-value">₽ ${escapeHtml(order.budget)}</span>
                    <span class="meta-item"><i class="fas fa-user"></i> ${escapeHtml(order.customer)}</span>
                </div>
                <div class="card-actions">
                    ${currentUser.role === 'freelancer'
                        ? alreadyResponded.has(order.id)
                            ? `<span class="btn-outline btn-sm" style="opacity:.5;cursor:default"><i class="fas fa-check"></i> Откликнулись</span>`
                            : `<button class="btn-primary btn-sm" data-order="${order.id}" data-action="response"><i class="fas fa-paper-plane"></i> Откликнуться</button>`
                        : ''}
                </div>
            </div>
        </div>
    `).join('');
    container.querySelectorAll('[data-action="response"]').forEach(btn => {
        btn.addEventListener('click', () => openResponseModal(btn.dataset.order));
    });
}

function renderMyOrders() {
    const container = document.getElementById('myOrdersList');
    if (currentUser.role !== 'customer') {
        container.innerHTML = `<div class="empty-state"><div class="empty-icon"><i class="fas fa-folder-open"></i></div><p>Только заказчики могут создавать заказы</p></div>`;
        return;
    }
    const myOrders = getMyOrders();
    if (!myOrders.length) {
        container.innerHTML = `<div class="empty-state"><div class="empty-icon"><i class="fas fa-folder-open"></i></div><p>У вас пока нет заказов</p></div>`;
        return;
    }
    container.innerHTML = myOrders.map(order => {
        const respCount = responses.filter(r => r.orderId === order.id).length;
        return `
        <div class="order-card">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap">
                <div>
                    <div class="order-category-tag"><i class="fas ${categoryIcon(order.category)}"></i> ${order.category}</div>
                    <div class="order-title">${escapeHtml(order.title)}</div>
                    <div class="order-desc">${escapeHtml(order.description)}</div>
                </div>
                ${statusLabel(order.status)}
            </div>
            <div class="order-footer">
                <span class="budget-value">₽ ${escapeHtml(order.budget)}</span>
                <div class="card-actions">
                    ${order.status === 'open' ? `<button class="btn-outline btn-sm" data-order="${order.id}" data-action="showResponses"><i class="fas fa-users"></i> Отклики (${respCount})</button>` : ''}
                </div>
            </div>
        </div>`;
    }).join('');
    container.querySelectorAll('[data-action="showResponses"]').forEach(btn => {
        btn.addEventListener('click', () => showResponsesModal(btn.dataset.order));
    });
}

function renderMyResponses() {
    const container = document.getElementById('myResponsesList');
    if (currentUser.role !== 'freelancer') {
        container.innerHTML = `<div class="empty-state"><div class="empty-icon"><i class="fas fa-paper-plane"></i></div><p>Только фрилансеры могут откликаться</p></div>`;
        return;
    }
    const myResponses = getMyResponses();
    if (!myResponses.length) {
        container.innerHTML = `<div class="empty-state"><div class="empty-icon"><i class="fas fa-paper-plane"></i></div><p>Вы ещё не откликались на заказы</p></div>`;
        return;
    }
    container.innerHTML = myResponses.map(resp => {
        const order = orders.find(o => o.id === resp.orderId);
        const chosen = order?.chosenFreelancer === currentUser.id;
        return `
        <div class="order-card">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap">
                <div>
                    <div class="order-title">${order ? escapeHtml(order.title) : 'Заказ удалён'}</div>
                    <div class="order-desc" style="-webkit-line-clamp:unset">${escapeHtml(resp.comment)}</div>
                </div>
                ${chosen ? '<span class="status-badge status-open"><i class="fas fa-trophy"></i> Выбраны!</span>' : statusLabel(order?.status || 'open')}
            </div>
            <div class="order-footer">
                <span class="budget-value">₽ ${escapeHtml(resp.price)}</span>
                <span class="meta-item"><i class="fas fa-clock"></i> ${resp.createdAt}</span>
            </div>
        </div>`;
    }).join('');
}

function renderDeals() {
    const container = document.getElementById('dealsList');
    const myDeals = getMyDeals();
    if (!myDeals.length) {
        container.innerHTML = `<div class="empty-state"><div class="empty-icon"><i class="fas fa-handshake"></i></div><p>Активных сделок нет</p></div>`;
        return;
    }
    container.innerHTML = myDeals.map(deal => `
        <div class="order-card">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap">
                <div>
                    <div class="order-title">${escapeHtml(deal.orderTitle)}</div>
                    <div style="display:flex;gap:16px;font-size:0.82rem;color:var(--text-muted);margin-top:4px;flex-wrap:wrap">
                        <span><i class="fas fa-building"></i> ${escapeHtml(deal.customerName)}</span>
                        <span><i class="fas fa-laptop-code"></i> ${escapeHtml(deal.freelancerName)}</span>
                    </div>
                </div>
                ${deal.status === 'in_progress' ? '<span class="status-badge status-progress">● В работе</span>' : '<span class="status-badge status-done">✓ Завершена</span>'}
            </div>
            <div class="order-footer">
                <span class="budget-value">₽ ${escapeHtml(deal.amount)}</span>
                <div class="card-actions">
                    ${deal.status === 'in_progress' && deal.customerId === currentUser.id
                        ? `<button class="btn-success btn-sm" data-deal="${deal.id}" data-action="complete"><i class="fas fa-check"></i> Подтвердить</button>` : ''}
                    ${deal.status === 'completed' && ((deal.customerId === currentUser.id && !deal.customerReviewed) || (deal.freelancerId === currentUser.id && !deal.freelancerReviewed))
                        ? `<button class="btn-outline btn-sm" data-deal="${deal.id}" data-action="review"><i class="fas fa-star"></i> Отзыв</button>` : ''}
                    <button class="btn-outline btn-sm" data-deal="${deal.id}" data-action="chat"><i class="fas fa-comments"></i> Чат</button>
                </div>
            </div>
        </div>
    `).join('');
    container.querySelectorAll('[data-action="complete"]').forEach(btn => {
        btn.addEventListener('click', () => {
            if (confirm('Подтвердить выполнение заказа?')) {
                completeDeal(btn.dataset.deal);
                showToast('Сделка завершена!');
                render();
            }
        });
    });
    container.querySelectorAll('[data-action="review"]').forEach(btn => {
        btn.addEventListener('click', () => openReviewModal(btn.dataset.deal));
    });
    container.querySelectorAll('[data-action="chat"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const deal = deals.find(d => d.id === btn.dataset.deal);
            if (deal) openChatModal(deal.orderId, deal.orderTitle);
        });
    });
}

// Responses modal (replaces alert/prompt)
function showResponsesModal(orderId) {
    const order = orders.find(o => o.id === orderId);
    const respList = responses.filter(r => r.orderId === orderId);
    document.getElementById('responsesListOrderTitle').textContent = order ? order.title : '';
    const container = document.getElementById('responsesListContainer');
    if (!respList.length) {
        container.innerHTML = `<div class="empty-state"><div class="empty-icon"><i class="fas fa-users"></i></div><p>Откликов пока нет</p></div>`;
    } else {
        container.innerHTML = respList.map(r => `
            <div class="response-item">
                <div class="response-author"><i class="fas fa-user"></i> ${escapeHtml(r.freelancerName)}</div>
                <div class="response-comment">${escapeHtml(r.comment)}</div>
                <div class="response-price"><i class="fas fa-coins"></i> ₽ ${escapeHtml(r.price)}</div>
                <div class="card-actions">
                    <button class="btn-primary btn-sm" data-fid="${r.freelancerId}" data-fname="${escapeHtml(r.freelancerName)}">
                        <i class="fas fa-handshake"></i> Выбрать исполнителем
                    </button>
                </div>
            </div>
        `).join('');
        container.querySelectorAll('[data-fid]').forEach(btn => {
            btn.addEventListener('click', () => {
                if (confirm(`Назначить ${btn.dataset.fname} исполнителем?`)) {
                    selectFreelancer(orderId, btn.dataset.fid);
                    closeModal('responsesListModal');
                    showToast(`${btn.dataset.fname} назначен исполнителем!`);
                    render();
                }
            });
        });
    }
    openModal('responsesListModal');
}

function openResponseModal(orderId) {
    const order = orders.find(o => o.id === orderId);
    document.getElementById('responseOrderTitle').textContent = order?.title || '';
    const modal = document.getElementById('responseModal');
    modal.dataset.orderId = orderId;
    openModal('responseModal');
}

function openChatModal(orderId, title) {
    const modal = document.getElementById('chatModal');
    document.getElementById('chatOrderTitle').textContent = title;
    modal.dataset.orderId = orderId;
    renderChatMessages(orderId);
    openModal('chatModal');
    setTimeout(() => {
        const msgs = document.getElementById('chatMessages');
        msgs.scrollTop = msgs.scrollHeight;
    }, 50);
}

function renderChatMessages(orderId) {
    const container = document.getElementById('chatMessages');
    const msgs = getMessages(orderId);
    if (!msgs.length) {
        container.innerHTML = `<div class="empty-state" style="padding:30px"><p>Нет сообщений. Начните общение!</p></div>`;
        return;
    }
    container.innerHTML = msgs.map(m => `
        <div class="message ${m.senderId === currentUser.id ? 'own' : ''}">
            <div class="msg-author">${m.senderId === currentUser.id ? 'Вы' : escapeHtml(m.senderName)}</div>
            <div class="msg-text">${escapeHtml(m.text)}</div>
            <div class="msg-time">${m.timestamp}</div>
        </div>
    `).join('');
}

function openReviewModal(dealId) {
    const deal = deals.find(d => d.id === dealId);
    const targetName = deal.freelancerId === currentUser.id ? deal.customerName : deal.freelancerName;
    document.getElementById('reviewFreelancerName').textContent = targetName;
    const modal = document.getElementById('reviewModal');
    modal.dataset.dealId = dealId;
    // reset stars
    document.querySelectorAll('.rating-stars span').forEach(s => s.classList.remove('active'));
    openModal('reviewModal');
}

// ---------- Init ----------
document.addEventListener('DOMContentLoaded', () => {
    loadData();
    if (!window.reviews) window.reviews = JSON.parse(localStorage.getItem('fl_reviews') || '[]');

    if (currentUser) {
        document.getElementById('mainContent').style.display = 'block';
        render();
    }

    // Close modals via backdrop or X button
    document.querySelectorAll('.modal').forEach(modal => {
        modal.querySelector('.modal-backdrop')?.addEventListener('click', () => { modal.style.display = 'none'; });
    });
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', () => closeModal(btn.dataset.modal));
    });

    // Login button
    document.getElementById('loginBtn').onclick = () => openModal('authModal');

    // Role selector
    let selectedRole = 'customer';
    document.querySelectorAll('.role-btn').forEach(btn => {
        btn.onclick = () => {
            document.querySelectorAll('.role-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            selectedRole = btn.dataset.role;
        };
    });

    // Auth submit
    document.getElementById('authSubmitBtn').onclick = () => {
        const name = document.getElementById('authName').value.trim();
        if (!name) { showToast('Введите имя', 'error'); return; }
        currentUser = { id: uid(), name, role: selectedRole, rating: 0 };
        saveAll();
        closeModal('authModal');
        document.getElementById('mainContent').style.display = 'block';
        render();
        showToast(`Добро пожаловать, ${name}!`);
    };
    document.getElementById('authName').addEventListener('keydown', e => {
        if (e.key === 'Enter') document.getElementById('authSubmitBtn').click();
    });

    // Create order button
    document.getElementById('createOrderBtn').onclick = () => {
        if (currentUser.role !== 'customer') {
            showToast('Только заказчики могут создавать заказы', 'error'); return;
        }
        openModal('createOrderModal');
    };

    // Submit order
    document.getElementById('submitOrderBtn').onclick = () => {
        const title  = document.getElementById('orderTitle').value.trim();
        const cat    = document.getElementById('orderCategory').value;
        const desc   = document.getElementById('orderDescription').value.trim();
        const budget = document.getElementById('orderBudget').value.trim();
        if (!title || !desc) { showToast('Заполните название и описание', 'error'); return; }
        createOrder(title, cat, desc, budget);
        closeModal('createOrderModal');
        document.getElementById('orderTitle').value = '';
        document.getElementById('orderDescription').value = '';
        document.getElementById('orderBudget').value = '';
        showToast('Заказ опубликован!');
        render();
    };

    // Submit response
    document.getElementById('submitResponseBtn').onclick = () => {
        const modal   = document.getElementById('responseModal');
        const orderId = modal.dataset.orderId;
        const comment = document.getElementById('responseComment').value.trim();
        const price   = document.getElementById('responsePrice').value.trim();
        if (!comment) { showToast('Напишите текст отклика', 'error'); return; }
        const ok = addResponse(orderId, comment, price);
        if (!ok) { showToast('Не удалось отправить (уже откликались?)', 'error'); return; }
        closeModal('responseModal');
        document.getElementById('responseComment').value = '';
        document.getElementById('responsePrice').value = '';
        showToast('Отклик отправлен!');
        render();
    };

    // Send chat message
    document.getElementById('sendMessageBtn').onclick = () => sendChat();
    document.getElementById('chatInput').addEventListener('keydown', e => {
        if (e.key === 'Enter') sendChat();
    });
    function sendChat() {
        const modal   = document.getElementById('chatModal');
        const orderId = modal.dataset.orderId;
        const text    = document.getElementById('chatInput').value.trim();
        if (!text) return;
        sendMessage(orderId, text);
        document.getElementById('chatInput').value = '';
        renderChatMessages(orderId);
        const msgs = document.getElementById('chatMessages');
        msgs.scrollTop = msgs.scrollHeight;
    }

    // Submit review
    document.getElementById('submitReviewBtn').onclick = () => {
        const modal   = document.getElementById('reviewModal');
        const dealId  = modal.dataset.dealId;
        const activeStar = document.querySelector('.rating-stars span.active');
        if (!activeStar) { showToast('Поставьте оценку', 'error'); return; }
        const rating  = parseInt(activeStar.dataset.rating);
        const text    = document.getElementById('reviewText').value.trim();
        const deal    = deals.find(d => d.id === dealId);
        const forFreelancer = deal.freelancerId !== currentUser.id;
        addReview(dealId, rating, text, forFreelancer);
        closeModal('reviewModal');
        document.getElementById('reviewText').value = '';
        showToast('Отзыв отправлен! Спасибо.');
        render();
    };

    // Rating stars
    document.querySelectorAll('.rating-stars span').forEach(star => {
        star.onclick = () => {
            document.querySelectorAll('.rating-stars span').forEach(s => s.classList.remove('active'));
            star.classList.add('active');
            let prev = star.previousElementSibling;
            while (prev) { prev.classList.add('active'); prev = prev.previousElementSibling; }
        };
    });

    // Navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.onclick = () => {
            document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const tab = btn.dataset.tab;
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
            document.getElementById(tab + 'Tab').classList.add('active');
            render();
        };
    });

    // Search/filter
    document.getElementById('searchOrders').addEventListener('input', e => {
        currentSearch = e.target.value;
        renderProjectsList();
    });
    document.getElementById('categoryFilter').addEventListener('change', e => {
        currentCategory = e.target.value;
        renderProjectsList();
    });
});
