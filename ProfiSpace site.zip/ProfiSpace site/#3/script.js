// ═══════════════════════════════════════
//  i18n — Translations
// ═══════════════════════════════════════
const TRANSLATIONS = {
    ru: {
        tagline:'Биржа удалённой работы',loginPrompt:'Войдите, чтобы продолжить',
        loginBtn:'Вход / Регистрация',welcome:'Добро пожаловать',
        chooseRole:'Выберите вашу роль на платформе',
        roleCustomer:'Заказчик',roleFreelancer:'Фрилансер',
        enterName:'Ваше имя',startWorking:'Начать работу',
        navProjects:'Лента заказов',navMyOrders:'Мои заказы',
        navMyResponses:'Мои отклики',navDeals:'Сделки',
        createOrder:'Создать заказ',newOrder:'Новый заказ',
        orderTitlePh:'Название заказа',orderDescPh:'Описание задач...',
        orderBudgetPh:'Бюджет (₽)',publishOrder:'Опубликовать заказ',
        responseTitle:'Отклик на заказ',
        responseCommentPh:'Ваше предложение, сроки, опыт...',
        responsePricePh:'Ваша цена (₽)',sendResponse:'Отправить отклик',
        responsesTitle:'Отклики исполнителей',
        typeMessage:'Введите сообщение...',leaveReview:'Оставить отзыв',
        executor:'Исполнитель:',reviewPh:'Ваш отзыв...',submitReview:'Отправить отзыв',
        searchPlaceholder:'Поиск по названию...',allCat:'Все категории',
        catWeb:'Веб-разработка',catDesign:'Дизайн',catMarketing:'Маркетинг',
        catMobile:'Мобильные приложения',catCopy:'Копирайтинг',
        statusOpen:'Открыт',statusInProgress:'В работе',statusDone:'Завершён',
        noOrders:'Нет открытых заказов',noMyOrders:'У вас пока нет заказов',
        noResponses:'Вы ещё не откликались на заказы',noDeals:'Активных сделок нет',
        respond:'Откликнуться',viewResponses:'Отклики',complete:'Завершить сделку',
        chat:'Чат',review:'Отзыв',customer:'Заказчик',freelancer:'Фрилансер',
        noResponsesYet:'Откликов пока нет',selectExecutor:'Выбрать исполнителем',
        confirmComplete:'Подтвердить выполнение и перевести оплату?',
        fillName:'Введите имя',fillTitle:'Заполните название и описание',
        fillComment:'Напишите текст отклика',alreadyResponded:'Вы уже откликались на этот заказ',
        onlyCustomers:'Только заказчики могут создавать заказы',
        orderCreated:'Заказ опубликован!',responseSent:'Отклик отправлен!',
        dealStarted:'Сделка началась!',dealCompleted:'Сделка завершена!',
        reviewSent:'Отзыв отправлен!',deletedOrder:'Удалённый заказ',
        waitingSelect:'Ожидает выбора',otherSelected:'Выбран другой исполнитель',
    },
    en: {
        tagline:'Remote work marketplace',loginPrompt:'Log in to continue',
        loginBtn:'Sign In / Register',welcome:'Welcome',
        chooseRole:'Choose your role on the platform',
        roleCustomer:'Customer',roleFreelancer:'Freelancer',
        enterName:'Your name',startWorking:'Get Started',
        navProjects:'Job Feed',navMyOrders:'My Orders',
        navMyResponses:'My Bids',navDeals:'Deals',
        createOrder:'Post a Job',newOrder:'New Order',
        orderTitlePh:'Order title',orderDescPh:'Describe the task...',
        orderBudgetPh:'Budget ($)',publishOrder:'Publish Order',
        responseTitle:'Apply for Order',
        responseCommentPh:'Your proposal, timeline, experience...',
        responsePricePh:'Your price ($)',sendResponse:'Send Proposal',
        responsesTitle:'Freelancer Proposals',
        typeMessage:'Type a message...',leaveReview:'Leave a Review',
        executor:'Freelancer:',reviewPh:'Your review...',submitReview:'Submit Review',
        searchPlaceholder:'Search by title...',allCat:'All Categories',
        catWeb:'Web Development',catDesign:'Design',catMarketing:'Marketing',
        catMobile:'Mobile Apps',catCopy:'Copywriting',
        statusOpen:'Open',statusInProgress:'In Progress',statusDone:'Completed',
        noOrders:'No open orders',noMyOrders:'You have no orders yet',
        noResponses:"You haven't applied to any orders yet",noDeals:'No active deals',
        respond:'Apply',viewResponses:'View Proposals',complete:'Mark Complete',
        chat:'Chat',review:'Review',customer:'Customer',freelancer:'Freelancer',
        noResponsesYet:'No proposals yet',selectExecutor:'Hire Freelancer',
        confirmComplete:'Confirm completion and release payment?',
        fillName:'Please enter your name',fillTitle:'Fill in title and description',
        fillComment:'Write your proposal',alreadyResponded:'You have already applied to this order',
        onlyCustomers:'Only customers can post orders',
        orderCreated:'Order published!',responseSent:'Proposal sent!',
        dealStarted:'Deal started!',dealCompleted:'Deal completed!',
        reviewSent:'Review submitted!',deletedOrder:'Deleted order',
        waitingSelect:'Awaiting selection',otherSelected:'Another freelancer was selected',
    },
    kz: {
        tagline:'Қашықтан жұмыс биржасы',loginPrompt:'Жалғастыру үшін кіріңіз',
        loginBtn:'Кіру / Тіркелу',welcome:'Қош келдіңіз',
        chooseRole:'Платформадағы рөліңізді таңдаңыз',
        roleCustomer:'Тапсырыс беруші',roleFreelancer:'Фрилансер',
        enterName:'Сіздің атыңыз',startWorking:'Жұмысты бастау',
        navProjects:'Тапсырыстар тізімі',navMyOrders:'Менің тапсырыстарым',
        navMyResponses:'Менің ұсыныстарым',navDeals:'Мәмілелер',
        createOrder:'Тапсырыс жасау',newOrder:'Жаңа тапсырыс',
        orderTitlePh:'Тапсырыс атауы',orderDescPh:'Тапсырманың сипаттамасы...',
        orderBudgetPh:'Бюджет (₸)',publishOrder:'Тапсырысты жариялау',
        responseTitle:'Тапсырысқа өтініш',
        responseCommentPh:'Ұсынысыңыз, мерзімдер, тәжірибе...',
        responsePricePh:'Сіздің бағаңыз (₸)',sendResponse:'Өтінімді жіберу',
        responsesTitle:'Фрилансерлердің өтініштері',
        typeMessage:'Хабарлама жазыңыз...',leaveReview:'Пікір қалдыру',
        executor:'Орындаушы:',reviewPh:'Пікіріңіз...',submitReview:'Пікір жіберу',
        searchPlaceholder:'Атауы бойынша іздеу...',allCat:'Барлық санаттар',
        catWeb:'Веб-әзірлеу',catDesign:'Дизайн',catMarketing:'Маркетинг',
        catMobile:'Мобильді қосымшалар',catCopy:'Копирайтинг',
        statusOpen:'Ашық',statusInProgress:'Жұмыста',statusDone:'Аяқталды',
        noOrders:'Ашық тапсырыстар жоқ',noMyOrders:'Сізде әлі тапсырыстар жоқ',
        noResponses:'Сіз әлі ешбір тапсырысқа жауап бермедіңіз',noDeals:'Белсенді мәмілелер жоқ',
        respond:'Өтінім беру',viewResponses:'Өтінімдерді қарау',complete:'Аяқтауды растау',
        chat:'Чат',review:'Пікір',customer:'Тапсырыс беруші',freelancer:'Фрилансер',
        noResponsesYet:'Әлі өтінімдер жоқ',selectExecutor:'Орындаушы ретінде таңдау',
        confirmComplete:'Аяқтауды растап, төлемді жіберу керек пе?',
        fillName:'Атыңызды енгізіңіз',fillTitle:'Атау мен сипаттаманы толтырыңыз',
        fillComment:'Өтінім мәтінін жазыңыз',alreadyResponded:'Сіз бұл тапсырысқа өтінім жібердіңіз',
        onlyCustomers:'Тапсырыстарды тек тапсырыс берушілер жасай алады',
        orderCreated:'Тапсырыс жарияланды!',responseSent:'Өтінім жіберілді!',
        dealStarted:'Мәміле басталды!',dealCompleted:'Мәміле аяқталды!',
        reviewSent:'Пікір жіберілді!',deletedOrder:'Жойылған тапсырыс',
        waitingSelect:'Таңдауды күтуде',otherSelected:'Басқа фрилансер таңдалды',
    }
};

let currentLang = localStorage.getItem('fl_lang') || 'ru';
function t(key) { return (TRANSLATIONS[currentLang] || TRANSLATIONS.ru)[key] || key; }

function applyTranslations() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
        el.textContent = t(el.getAttribute('data-i18n'));
    });
    document.querySelectorAll('[data-i18n-ph]').forEach(el => {
        el.placeholder = t(el.getAttribute('data-i18n-ph'));
    });
    document.querySelectorAll('option[data-i18n]').forEach(el => {
        el.textContent = t(el.getAttribute('data-i18n'));
    });
    if (currentUser) {
        const roleLabel = currentUser.role === 'customer' ? t('customer') : t('freelancer');
        document.getElementById('userStatus').innerHTML =
            `<i class="fas fa-user"></i> ${escapeHtml(currentUser.name)} <span style="opacity:0.6">(${roleLabel})</span>`;
    }
    renderProfile();
}

// ═══════════════════════════════════════
//  Theme
// ═══════════════════════════════════════
let currentTheme = localStorage.getItem('fl_theme') || 'light';
function applyTheme(theme) {
    currentTheme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    localStorage.setItem('fl_theme', theme);
}

// ═══════════════════════════════════════
//  Data Model
// ═══════════════════════════════════════
let currentUser = null, orders = [], responses = [], deals = [], messages = [];

function loadData() {
    const su = localStorage.getItem('fl_user');
    if (su) currentUser = JSON.parse(su);
    orders    = JSON.parse(localStorage.getItem('fl_orders')    || '[]');
    responses = JSON.parse(localStorage.getItem('fl_responses') || '[]');
    deals     = JSON.parse(localStorage.getItem('fl_deals')     || '[]');
    messages  = JSON.parse(localStorage.getItem('fl_messages')  || '[]');
    if (!window.reviews) window.reviews = JSON.parse(localStorage.getItem('fl_reviews') || '[]');
}
function saveAll() {
    if (currentUser) localStorage.setItem('fl_user', JSON.stringify(currentUser));
    localStorage.setItem('fl_orders',    JSON.stringify(orders));
    localStorage.setItem('fl_responses', JSON.stringify(responses));
    localStorage.setItem('fl_deals',     JSON.stringify(deals));
    localStorage.setItem('fl_messages',  JSON.stringify(messages));
    localStorage.setItem('fl_reviews',   JSON.stringify(window.reviews || []));
}
function uid() { return Date.now() + '-' + Math.random().toString(36).substr(2,6); }

function createOrder(title, category, description, budget) {
    if (!currentUser || currentUser.role !== 'customer') return false;
    orders.unshift({ id:uid(), title, category, description,
        budget: budget||'—', customer:currentUser.name, customerId:currentUser.id,
        status:'open', createdAt:new Date().toLocaleString(), chosenFreelancer:null });
    saveAll(); return true;
}
function addResponse(orderId, comment, price) {
    if (!currentUser || currentUser.role !== 'freelancer') return false;
    const order = orders.find(o=>o.id===orderId);
    if (!order || order.status!=='open') return false;
    if (responses.find(r=>r.orderId===orderId&&r.freelancerId===currentUser.id)) return false;
    responses.push({ id:uid(), orderId, freelancerId:currentUser.id,
        freelancerName:currentUser.name, comment, price:price||order.budget,
        createdAt:new Date().toLocaleString() });
    saveAll(); return true;
}
function selectFreelancer(orderId, freelancerId) {
    const order = orders.find(o=>o.id===orderId);
    if (!order || order.customerId!==currentUser.id) return false;
    const resp = responses.find(r=>r.orderId===orderId&&r.freelancerId===freelancerId);
    if (!resp) return false;
    deals.push({ id:uid(), orderId, orderTitle:order.title,
        customerId:order.customerId, customerName:order.customer,
        freelancerId, freelancerName:resp.freelancerName,
        amount:resp.price, status:'in_progress',
        createdAt:new Date().toLocaleString(), completedAt:null,
        customerReviewed:false, freelancerReviewed:false });
    order.status='in_progress'; order.chosenFreelancer=freelancerId;
    saveAll(); return true;
}
function completeDeal(dealId) {
    const deal = deals.find(d=>d.id===dealId);
    if (!deal || deal.customerId!==currentUser.id) return false;
    deal.status='completed'; deal.completedAt=new Date().toLocaleString();
    const order = orders.find(o=>o.id===deal.orderId);
    if (order) order.status='completed';
    saveAll(); return true;
}
function addReview(dealId, rating, text, forFreelancer=true) {
    const deal = deals.find(d=>d.id===dealId);
    if (!deal) return false;
    const targetId = forFreelancer ? deal.freelancerId : deal.customerId;
    if (!window.reviews) window.reviews=[];
    window.reviews.push({ id:uid(), targetId, authorId:currentUser.id,
        authorName:currentUser.name, rating, text, createdAt:new Date().toLocaleString() });
    if (forFreelancer) deal.customerReviewed=true; else deal.freelancerReviewed=true;
    saveAll(); return true;
}
function sendMessage(orderId, text) {
    if (!currentUser) return false;
    messages.push({ id:uid(), orderId, senderId:currentUser.id,
        senderName:currentUser.name, text, timestamp:new Date().toLocaleString() });
    saveAll(); return true;
}
function getMessages(orderId) {
    return messages.filter(m=>m.orderId===orderId).sort((a,b)=>a.timestamp.localeCompare(b.timestamp));
}
function getUserRating(userId) {
    const ur=(window.reviews||[]).filter(r=>r.targetId===userId);
    if(!ur.length) return null;
    return (ur.reduce((s,r)=>s+r.rating,0)/ur.length).toFixed(1);
}
function getMyOrders()    { return orders.filter(o=>o.customerId===currentUser.id); }
function getMyResponses() { return responses.filter(r=>r.freelancerId===currentUser.id); }
function getMyDeals()     { return deals.filter(d=>d.customerId===currentUser.id||d.freelancerId===currentUser.id); }

// ── Helpers ──
function escapeHtml(str) {
    if(!str) return '';
    return str.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
function showToast(msg) {
    const toast = document.getElementById('toast');
    toast.textContent = msg; toast.classList.add('show');
    setTimeout(()=>toast.classList.remove('show'), 2800);
}
function statusBadge(status) {
    if(status==='open')        return `<span class="status-badge status-open"><i class="fas fa-circle" style="font-size:.5rem"></i> ${t('statusOpen')}</span>`;
    if(status==='in_progress') return `<span class="status-badge status-inprog"><i class="fas fa-circle" style="font-size:.5rem"></i> ${t('statusInProgress')}</span>`;
    return `<span class="status-badge status-done"><i class="fas fa-check"></i> ${t('statusDone')}</span>`;
}
function getCatLabel(val) {
    const map={web:'catWeb',design:'catDesign',marketing:'catMarketing',mobile:'catMobile',copy:'catCopy'};
    return t(map[val]||val)||val;
}

// ═══════════════════════════════════════
//  Rendering
// ═══════════════════════════════════════
let currentSearch='', currentCategory='';

function render() {
    if(!currentUser) return;
    renderProfile(); renderProjectsList(); renderMyOrders(); renderMyResponses(); renderDeals();
}

function renderProfile() {
    const card = document.getElementById('profileCard');
    if(!card||!currentUser) return;
    const rating = getUserRating(currentUser.id);
    const reviewCount = (window.reviews||[]).filter(r=>r.targetId===currentUser.id).length;
    const roleLabel = currentUser.role==='customer' ? t('customer') : t('freelancer');
    card.innerHTML = `
        <div class="avatar-wrap"><i class="fas fa-user"></i></div>
        <div class="profile-name">${escapeHtml(currentUser.name)}</div>
        <div class="profile-role">${roleLabel}</div>
        ${rating ? `<div class="profile-rating"><i class="fas fa-star"></i> ${rating} <span style="font-size:.8rem;color:var(--text-3)">(${reviewCount})</span></div>` : ''}
    `;
}

function renderProjectsList() {
    const container = document.getElementById('projectsList');
    let filtered = orders.filter(o=>o.status==='open');
    if(currentSearch)   filtered=filtered.filter(o=>o.title.toLowerCase().includes(currentSearch.toLowerCase()));
    if(currentCategory) filtered=filtered.filter(o=>o.category===currentCategory);
    const countEl = document.getElementById('orderCount');
    if(countEl) countEl.textContent = filtered.length;

    if(!filtered.length) {
        container.innerHTML=`<div class="empty-state" style="grid-column:1/-1"><i class="fas fa-inbox"></i><p>${t('noOrders')}</p></div>`;
        return;
    }
    container.innerHTML = filtered.map(order => {
        const respCount = responses.filter(r=>r.orderId===order.id).length;
        const alreadyApplied = responses.find(r=>r.orderId===order.id&&r.freelancerId===currentUser.id);
        const canRespond = currentUser.role==='freelancer' && !alreadyApplied;
        return `<div class="order-card">
            <div class="card-top">
                <div class="order-title">${escapeHtml(order.title)}</div>
                <span class="cat-badge">${getCatLabel(order.category)}</span>
            </div>
            <div class="description">${escapeHtml(order.description)}</div>
            <div class="order-meta">
                <span class="budget"><i class="fas fa-coins"></i> ${escapeHtml(order.budget)}</span>
                <span><i class="fas fa-user"></i> ${escapeHtml(order.customer)}</span>
                ${respCount?`<span><i class="fas fa-reply"></i> ${respCount}</span>`:''}
            </div>
            <div class="card-actions">
                ${canRespond?`<button class="btn-primary btn-sm" data-order="${order.id}" data-action="response"><i class="fas fa-reply"></i> ${t('respond')}</button>`:''}
            </div>
        </div>`;
    }).join('');
    container.querySelectorAll('[data-action="response"]').forEach(btn=>
        btn.addEventListener('click',()=>openResponseModal(btn.getAttribute('data-order')))
    );
}

function renderMyOrders() {
    const container = document.getElementById('myOrdersList');
    if(currentUser.role!=='customer') {
        container.innerHTML=`<div class="empty-state"><i class="fas fa-info-circle"></i><p>${t('noMyOrders')}</p></div>`; return;
    }
    const myOrders = getMyOrders();
    if(!myOrders.length) {
        container.innerHTML=`<div class="empty-state"><i class="fas fa-folder-open"></i><p>${t('noMyOrders')}</p></div>`; return;
    }
    container.innerHTML=`<div class="projects-grid">${myOrders.map(order=>{
        const respCount=responses.filter(r=>r.orderId===order.id).length;
        return `<div class="order-card">
            <div class="card-top"><div class="order-title">${escapeHtml(order.title)}</div>${statusBadge(order.status)}</div>
            <div class="description">${escapeHtml(order.description)}</div>
            <div class="order-meta">
                <span class="budget"><i class="fas fa-coins"></i> ${escapeHtml(order.budget)}</span>
                <span><i class="fas fa-reply"></i> ${respCount}</span>
            </div>
            <div class="card-actions">
                ${order.status==='open'?`<button class="btn-outline btn-sm" data-order="${order.id}" data-action="showResponses"><i class="fas fa-users"></i> ${t('viewResponses')} (${respCount})</button>`:''}
            </div>
        </div>`;
    }).join('')}</div>`;
    container.querySelectorAll('[data-action="showResponses"]').forEach(btn=>
        btn.addEventListener('click',()=>openResponsesListModal(btn.getAttribute('data-order')))
    );
}

function renderMyResponses() {
    const container = document.getElementById('myResponsesList');
    if(currentUser.role!=='freelancer') {
        container.innerHTML=`<div class="empty-state"><i class="fas fa-info-circle"></i><p>${t('noResponses')}</p></div>`; return;
    }
    const myResp = getMyResponses();
    if(!myResp.length) {
        container.innerHTML=`<div class="empty-state"><i class="fas fa-paper-plane"></i><p>${t('noResponses')}</p></div>`; return;
    }
    container.innerHTML=`<div class="projects-grid">${myResp.map(resp=>{
        const order=orders.find(o=>o.id===resp.orderId);
        let st=t('waitingSelect');
        if(order?.status==='in_progress'&&order.chosenFreelancer!==currentUser.id) st=t('otherSelected');
        if(order?.chosenFreelancer===currentUser.id&&order?.status==='in_progress') st=t('statusInProgress');
        if(order?.status==='completed') st=t('statusDone');
        return `<div class="order-card">
            <div class="card-top"><div class="order-title">${order?escapeHtml(order.title):t('deletedOrder')}</div></div>
            <div class="description">${escapeHtml(resp.comment)}</div>
            <div class="order-meta">
                <span class="budget"><i class="fas fa-coins"></i> ${escapeHtml(resp.price)}</span>
                <span><i class="fas fa-info-circle"></i> ${st}</span>
            </div>
        </div>`;
    }).join('')}</div>`;
}

function renderDeals() {
    const container = document.getElementById('dealsList');
    const myDeals = getMyDeals();
    if(!myDeals.length) {
        container.innerHTML=`<div class="empty-state"><i class="fas fa-handshake"></i><p>${t('noDeals')}</p></div>`; return;
    }
    container.innerHTML=`<div class="projects-grid">${myDeals.map(deal=>`
        <div class="order-card">
            <div class="card-top"><div class="order-title">${escapeHtml(deal.orderTitle)}</div>${statusBadge(deal.status==='in_progress'?'in_progress':'completed')}</div>
            <div class="order-meta">
                <span><i class="fas fa-user"></i> ${escapeHtml(deal.customerName)} → ${escapeHtml(deal.freelancerName)}</span>
                <span class="budget"><i class="fas fa-coins"></i> ${escapeHtml(deal.amount)}</span>
            </div>
            <div class="card-actions">
                ${deal.status==='in_progress'&&deal.customerId===currentUser.id
                    ?`<button class="btn-primary btn-sm" data-deal="${deal.id}" data-action="complete"><i class="fas fa-check"></i> ${t('complete')}</button>`:''}
                ${deal.status==='completed'&&((deal.customerId===currentUser.id&&!deal.customerReviewed)||(deal.freelancerId===currentUser.id&&!deal.freelancerReviewed))
                    ?`<button class="btn-outline btn-sm" data-deal="${deal.id}" data-action="review"><i class="fas fa-star"></i> ${t('review')}</button>`:''}
                <button class="btn-outline btn-sm" data-deal="${deal.id}" data-action="chat"><i class="fas fa-comments"></i> ${t('chat')}</button>
            </div>
        </div>
    `).join('')}</div>`;
    container.querySelectorAll('[data-action="complete"]').forEach(btn=>
        btn.addEventListener('click',()=>{
            if(confirm(t('confirmComplete'))){completeDeal(btn.getAttribute('data-deal'));showToast(t('dealCompleted'));render();}
        })
    );
    container.querySelectorAll('[data-action="review"]').forEach(btn=>
        btn.addEventListener('click',()=>openReviewModal(btn.getAttribute('data-deal')))
    );
    container.querySelectorAll('[data-action="chat"]').forEach(btn=>{
        btn.addEventListener('click',()=>{
            const deal=deals.find(d=>d.id===btn.getAttribute('data-deal'));
            if(deal) openChatModal(deal.orderId,deal.orderTitle);
        });
    });
}

// ═══════════════════════════════════════
//  Modal Openers
// ═══════════════════════════════════════
function openResponseModal(orderId) {
    const modal=document.getElementById('responseModal');
    const order=orders.find(o=>o.id===orderId);
    document.getElementById('responseOrderTitle').textContent=order?order.title:'';
    document.getElementById('responseComment').value='';
    document.getElementById('responsePrice').value='';
    modal.dataset.orderId=orderId; modal.style.display='flex';
}
function openResponsesListModal(orderId) {
    const modal=document.getElementById('responsesListModal');
    const order=orders.find(o=>o.id===orderId);
    document.getElementById('responsesOrderTitle').textContent=order?order.title:'';
    modal.dataset.orderId=orderId;
    const respList=responses.filter(r=>r.orderId===orderId);
    const container=document.getElementById('responsesListContainer');
    if(!respList.length) {
        container.innerHTML=`<div class="empty-state"><i class="fas fa-inbox"></i><p>${t('noResponsesYet')}</p></div>`;
    } else {
        container.innerHTML=respList.map(r=>`
            <div class="response-item">
                <div class="response-item-header">
                    <span class="response-freelancer"><i class="fas fa-user-circle"></i> ${escapeHtml(r.freelancerName)}</span>
                    <span class="response-price"><i class="fas fa-coins"></i> ${escapeHtml(r.price)}</span>
                </div>
                <div class="response-comment">${escapeHtml(r.comment)}</div>
                <div class="response-item-footer">
                    <button class="btn-primary btn-sm" data-fid="${r.freelancerId}">
                        <i class="fas fa-handshake"></i> ${t('selectExecutor')}
                    </button>
                </div>
            </div>
        `).join('');
        container.querySelectorAll('[data-fid]').forEach(btn=>{
            btn.addEventListener('click',()=>{
                selectFreelancer(orderId,btn.getAttribute('data-fid'));
                modal.style.display='none';
                showToast(t('dealStarted')); render();
            });
        });
    }
    modal.style.display='flex';
}
function openChatModal(orderId,title) {
    const modal=document.getElementById('chatModal');
    document.getElementById('chatOrderTitle').textContent=title;
    document.getElementById('chatInput').value='';
    modal.dataset.orderId=orderId; modal.style.display='flex';
    renderChatMessages(orderId);
}
function renderChatMessages(orderId) {
    const container=document.getElementById('chatMessages');
    const msgs=getMessages(orderId);
    container.innerHTML=msgs.length?msgs.map(m=>`
        <div class="message ${m.senderId===currentUser.id?'own':''}">
            <strong>${escapeHtml(m.senderName)}</strong>
            ${escapeHtml(m.text)}<small>${m.timestamp}</small>
        </div>
    `).join(''):`<div class="empty-state" style="padding:20px"><i class="fas fa-comments"></i><p>${t('typeMessage')}</p></div>`;
    container.scrollTop=container.scrollHeight;
}
function openReviewModal(dealId) {
    const deal=deals.find(d=>d.id===dealId);
    const modal=document.getElementById('reviewModal');
    const targetName=deal.freelancerId===currentUser.id?deal.customerName:deal.freelancerName;
    document.getElementById('reviewFreelancerName').textContent=targetName;
    document.getElementById('reviewText').value='';
    document.querySelectorAll('.rating-stars span').forEach(s=>s.classList.remove('active'));
    modal.dataset.dealId=dealId; modal.style.display='flex';
}

// ═══════════════════════════════════════
//  Init
// ═══════════════════════════════════════
document.addEventListener('DOMContentLoaded',()=>{
    loadData();
    applyTheme(currentTheme);

    // Set active lang btn
    document.querySelectorAll('.lang-btn').forEach(btn=>{
        btn.classList.toggle('active', btn.dataset.lang===currentLang);
    });
    applyTranslations();

    if(currentUser) {
        document.getElementById('mainContent').style.display='block';
        applyTranslations();
        render();
    }

    // Language
    document.querySelectorAll('.lang-btn').forEach(btn=>{
        btn.addEventListener('click',()=>{
            document.querySelectorAll('.lang-btn').forEach(b=>b.classList.remove('active'));
            btn.classList.add('active');
            currentLang=btn.dataset.lang;
            localStorage.setItem('fl_lang',currentLang);
            applyTranslations();
            render();
        });
    });

    // Theme
    document.getElementById('themeToggle').addEventListener('click',()=>{
        applyTheme(currentTheme==='light'?'dark':'light');
    });

    // Close modals
    document.querySelectorAll('.modal .close').forEach(btn=>
        btn.addEventListener('click',()=>btn.closest('.modal').style.display='none')
    );
    document.querySelectorAll('.modal').forEach(modal=>
        modal.addEventListener('click',e=>{ if(e.target===modal) modal.style.display='none'; })
    );

    // Auth
    document.getElementById('loginBtn').addEventListener('click',()=>{
        document.getElementById('authModal').style.display='flex';
    });
    let selectedRole='customer';
    document.querySelectorAll('.role-btn').forEach(btn=>{
        btn.addEventListener('click',()=>{
            document.querySelectorAll('.role-btn').forEach(b=>b.classList.remove('active'));
            btn.classList.add('active'); selectedRole=btn.dataset.role;
        });
    });
    document.getElementById('authSubmitBtn').addEventListener('click',()=>{
        const name=document.getElementById('authName').value.trim();
        if(!name){showToast(t('fillName'));return;}
        currentUser={id:uid(),name,role:selectedRole,rating:0};
        saveAll();
        document.getElementById('authModal').style.display='none';
        document.getElementById('mainContent').style.display='block';
        applyTranslations(); render();
    });

    // Create Order
    document.getElementById('createOrderBtn').addEventListener('click',()=>{
        if(currentUser.role!=='customer'){showToast(t('onlyCustomers'));return;}
        ['orderTitle','orderDescription','orderBudget'].forEach(id=>document.getElementById(id).value='');
        document.getElementById('createOrderModal').style.display='flex';
    });
    document.getElementById('submitOrderBtn').addEventListener('click',()=>{
        const title=document.getElementById('orderTitle').value.trim();
        const cat=document.getElementById('orderCategory').value;
        const desc=document.getElementById('orderDescription').value.trim();
        const budget=document.getElementById('orderBudget').value.trim();
        if(!title||!desc){showToast(t('fillTitle'));return;}
        createOrder(title,cat,desc,budget);
        document.getElementById('createOrderModal').style.display='none';
        showToast(t('orderCreated')); render();
    });

    // Submit Response
    document.getElementById('submitResponseBtn').addEventListener('click',()=>{
        const modal=document.getElementById('responseModal');
        const orderId=modal.dataset.orderId;
        const comment=document.getElementById('responseComment').value.trim();
        const price=document.getElementById('responsePrice').value.trim();
        if(!comment){showToast(t('fillComment'));return;}
        const result=addResponse(orderId,comment,price);
        if(!result){showToast(t('alreadyResponded'));return;}
        modal.style.display='none'; showToast(t('responseSent')); render();
    });

    // Chat
    function sendChatMsg(){
        const modal=document.getElementById('chatModal');
        const orderId=modal.dataset.orderId;
        const text=document.getElementById('chatInput').value.trim();
        if(!text) return;
        sendMessage(orderId,text);
        document.getElementById('chatInput').value='';
        renderChatMessages(orderId);
    }
    document.getElementById('sendMessageBtn').addEventListener('click',sendChatMsg);
    document.getElementById('chatInput').addEventListener('keydown',e=>{if(e.key==='Enter')sendChatMsg();});

    // Stars
    document.querySelectorAll('.rating-stars span').forEach(star=>{
        star.addEventListener('click',()=>{
            document.querySelectorAll('.rating-stars span').forEach(s=>s.classList.remove('active'));
            star.classList.add('active');
            let prev=star.previousElementSibling;
            while(prev){prev.classList.add('active');prev=prev.previousElementSibling;}
        });
    });

    // Review
    document.getElementById('submitReviewBtn').addEventListener('click',()=>{
        const modal=document.getElementById('reviewModal');
        const dealId=modal.dataset.dealId;
        const rating=parseInt(document.querySelector('.rating-stars span.active')?.dataset.rating||'5');
        const text=document.getElementById('reviewText').value.trim();
        const deal=deals.find(d=>d.id===dealId);
        addReview(dealId,rating,text,deal.freelancerId!==currentUser.id);
        modal.style.display='none'; showToast(t('reviewSent')); render();
    });

    // Navigation
    document.querySelectorAll('.nav-btn').forEach(btn=>{
        btn.addEventListener('click',()=>{
            document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active'));
            btn.classList.add('active');
            document.querySelectorAll('.tab-content').forEach(tc=>tc.classList.remove('active'));
            const map={projects:'projectsTab',myOrders:'myOrdersTab',myResponses:'myResponsesTab',deals:'dealsTab'};
            const tab=document.getElementById(map[btn.dataset.tab]);
            if(tab) tab.classList.add('active');
            render();
        });
    });

    // Search / Filter
    document.getElementById('searchOrders').addEventListener('input',e=>{currentSearch=e.target.value;renderProjectsList();});
    document.getElementById('categoryFilter').addEventListener('change',e=>{currentCategory=e.target.value;renderProjectsList();});
});
