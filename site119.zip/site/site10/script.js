﻿// Navbar background change on scroll
window.addEventListener("scroll", function () {
    const nav = document.querySelector(".navbar");
    if (window.scrollY > 50) {
        nav.style.background = "rgba(0,0,0,0.95)";
    } else {
        nav.style.background = "rgba(0,0,0,0.8)";
    }
});

// ---- AVATAR ----
function getInitials(name) {
    return name.trim().charAt(0).toUpperCase();
}

function checkAuth() {
    const user = localStorage.getItem('cody_user');
    if (user) {
        const loginLink = document.getElementById('loginLink');
        const avatarWrap = document.getElementById('avatarWrap');
        if (loginLink) loginLink.style.display = 'none';
        if (avatarWrap) avatarWrap.style.display = 'block';
        const circle = document.getElementById('avatarCircle');
        if (circle) circle.textContent = getInitials(user);
        const username = document.getElementById('dropUsername');
        if (username) username.textContent = user;
    } else {
        const loginLink = document.getElementById('loginLink');
        const avatarWrap = document.getElementById('avatarWrap');
        if (loginLink) loginLink.style.display = 'inline';
        if (avatarWrap) avatarWrap.style.display = 'none';
    }
}

function toggleDropdown() {
    const dropdown = document.getElementById('avatarDropdown');
    if (dropdown) dropdown.classList.toggle('open');
}

function doLogout() {
    localStorage.removeItem('cody_user');
    checkAuth();
    const dropdown = document.getElementById('avatarDropdown');
    if (dropdown) dropdown.classList.remove('open');
}

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
    const wrap = document.getElementById('avatarWrap');
    if (wrap && !wrap.contains(e.target)) {
        const dropdown = document.getElementById('avatarDropdown');
        if (dropdown) dropdown.classList.remove('open');
    }
});

checkAuth();

// ============ GLOBAL VARIABLES ============
let lang = 'en';
let dark = true;

// ============ UNIFIED LANGUAGE SYSTEM ============
// Master translation object with all languages and keys
const T = {
    en: {
        nav_login: "Login", nav_about: "About", nav_foundation: "Foundation", nav_learning: "Learning",
        hero_title: "Cody Tech", hero_desc: "Cody Tech is a modern technology platform focused on programming languages, software development, and building a strong developer ecosystem.",
        btn_start: "Start Learning", about_title: "About", about_desc: "Our mission is to create a space where developers grow — from fundamentals to advanced engineering.",
        found_title: "Foundation", card1_title: "Goal: Build the core infrastructure", card1_desc: "Launch of the Cody Tech platform. Structured programming fundamentals",
        card2_title: "Core language tracks:", card2_desc: "JavaScript, HTML, CSS. Hands-on coding challenges. Documentation & real-world examples",
        card3_title: "Ecosystem", card3_desc: "Goal: Build a developer environment. Open-source projects. Collaboration tools. Version control. Community-driven development.",
        ready_title: "Ready to Start?", footer_txt: "Web Development Courses (HTML, CSS, JavaScript).",
        drop_role: "Student", drop_profile: "My Profile", drop_courses: "My Courses", drop_settings: "Settings", drop_logout: "Logout",
        back: "Back to Courses", title: "Course Page",
        s1_title: "Introduction", s1_intro: "Welcome to this course section.",
        challenge: "Complete the challenge for this section.",
    },
    ru: {
        nav_login: "Войти", nav_about: "О нас", nav_foundation: "Основы", nav_learning: "Обучение",
        hero_title: "Cody Tech", hero_desc: "Cody Tech — современная платформа, сосредоточенная на языках программирования, разработке ПО и создании сильного сообщества разработчиков.",
        btn_start: "Начать обучение", about_title: "О нас", about_desc: "Наша миссия — создать пространство, где разработчики растут от основ до продвинутой инженерии.",
        found_title: "Основы", card1_title: "Цель: Построить базовую инфраструктуру", card1_desc: "Запуск платформы Cody Tech. Структурированные основы программирования",
        card2_title: "Основные языковые треки:", card2_desc: "JavaScript, HTML, CSS. Практические задачи по кодированию. Документация и примеры из реальной жизни",
        card3_title: "Экосистема", card3_desc: "Цель: Построить среду разработчика. Open-source проекты. Инструменты сотрудничества. Контроль версий. Разработка, управляемая сообществом.",
        ready_title: "Готовы начать?", footer_txt: "Курсы веб-разработки (HTML, CSS, JavaScript).",
        drop_role: "Студент", drop_profile: "Мой профиль", drop_courses: "Мои курсы", drop_settings: "Параметры", drop_logout: "Выйти",
        back: "Назад к курсам", title: "Страница курса",
        s1_title: "Введение", s1_intro: "Добро пожаловать в этот раздел курса.",
        challenge: "Выполните задание для этого раздела.",
    },
    kz: {
        nav_login: "Кіру", nav_about: "Біз туралы", nav_foundation: "Негіздер", nav_learning: "Оқыту",
        hero_title: "Cody Tech", hero_desc: "Cody Tech — бағдарламалау тілдеріне, бағдарлама құрылымына және өндіруші ынамдастығын құруға бағытталған заманауи платформа.",
        btn_start: "Оқыту бастау", about_title: "Біз туралы", about_desc: "Біздің миссиялар өндіруштердің негіздерінен озық инженерциялық деңгейге өсетін орын құру.",
        found_title: "Негіздер", card1_title: "Мақсат: Негіздеген инфрақұрылымын құру", card1_desc: "Cody Tech платформасын іске қосу. Бағдарламалаудың құрылымдалған негіздері",
        card2_title: "Негізгі тіл бағыттары:", card2_desc: "JavaScript, HTML, CSS. Практикалық кодтау сынақтары. Құжаттама және нақты әлемдік мысалдар",
        card3_title: "Экожүйе", card3_desc: "Мақсат: Әзірлеу ортасын құру. Ашық бастапқы жобалар. Ынамдастық құралдары. Нұсқа бақылауы. Ынамдастық ұйытқылы өндіріс.",
        ready_title: "Бастауға дайын ба?", footer_txt: "Веб-әзірлеу курстары (HTML, CSS, JavaScript).",
        drop_role: "Студент", drop_profile: "Менің профилім", drop_courses: "Менің курстарым", drop_settings: "Баптаулар", drop_logout: "Шығу",
        back: "Курстарға оралу", title: "Курс беті",
        s1_title: "Кіріспе", s1_intro: "Осы курс бөліміне қош келдіңіз.",
        challenge: "Осы бөлім үшін тапсырманы орындаңыз.",
    }
};

// ============ LANGUAGE & THEME FUNCTIONS ============
function setLang(l, btn) {
    lang = l;
    // Update button states
    document.querySelectorAll('.ctrl-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    
    // Get translations
    const translations = T[l] || {};
    
    // Update all elements with data-i attribute
    document.querySelectorAll('[data-i]').forEach(el => {
        const key = el.getAttribute('data-i');
        if (translations[key] !== undefined) {
            el.textContent = translations[key];
        }
    });
    
    // Update page title if exists
    if (translations.title && translations.title !== "Course Page" && translations.title !== "Страница курса" && translations.title !== "Курс беті") {
        document.title = translations.title + " — Cody Tech";
    }
}

function toggleTheme() {
    dark = !dark;
    document.body.classList.toggle('light', !dark);
    const btn = document.getElementById('themeBtn');
    if (btn) {
        btn.textContent = dark ? '🌙' : '☀️';
    }
}

// Initialize theme button on load
window.addEventListener('load', function() {
    const themeBtn = document.getElementById('themeBtn');
    if (themeBtn) {
        themeBtn.textContent = dark ? '🌙' : '☀️';
    }
});

// ============ PAGE-SPECIFIC CODE ============

// Modal functionality
const modal = document.getElementById("loginModal");
const openBtn = document.getElementById("openLogin");
const closeBtn = document.querySelector(".close");

if (openBtn) {
    openBtn.onclick = () => {
        if (modal) modal.style.display = "block";
    };
}

if (closeBtn) {
    closeBtn.onclick = () => {
        if (modal) modal.style.display = "none";
    };
}

window.onclick = (e) => {
    if (e.target === modal && modal) {
        modal.style.display = "none";
    }
};

const loginForm = document.getElementById("loginForm");
if (loginForm) {
    loginForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const login = document.getElementById("login").value;
        const pass = document.getElementById("password").value;

        if (login === "admin" && pass === "1234") {
            alert("Вход выполнен!");
            if (modal) modal.style.display = "none";
        } else {
            alert("Неверный логин или пароль");
        }
    });
}

// Fade-in animation on scroll for learn pages
const sections = document.querySelectorAll(".section, .learn-section");
if (sections.length > 0) {
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = 1;
                entry.target.style.transform = "translateY(0)";
            }
        });
    });

    sections.forEach(section => {
        section.style.opacity = 0;
        section.style.transform = "translateY(50px)";
        section.style.transition = "all 0.8s ease";
        observer.observe(section);
    });
}

// Sidebar scroll tracking for learn pages
const secs = document.querySelectorAll('.learn-section');
const links = document.querySelectorAll('.sidebar-link');

if (secs.length > 0 && links.length > 0) {
    window.addEventListener('scroll', () => {
        let cur = '';
        secs.forEach(s => {
            if (window.scrollY >= s.offsetTop - 120) cur = s.id;
        });
        links.forEach(l => {
            l.classList.toggle('active', l.getAttribute('href') === '#' + cur);
        });
    });
}

