// Объект с переводами для трёх языков
// Ключи (ru, en, kz) — это коды языков
// Внутри каждого языка — пары "ключ: текст"
const translations = {

  ru: {
    title: 'Привет, я <span style="color:#f97316">Zhanuzak</span> 👋',
    'about-text': 'Я frontend разработчик и создаю современные сайты.',
    navAbout: 'Обо мне',
    navSkills: 'Навыки',
    navProjects: 'Проекты',
    navContact: 'Контакты',
    secAbout: 'Обо мне',
    secSkills: 'Навыки',
    secProjects: 'Проекты',
    secContact: 'Контакты',
    btnPS: 'ProfiSpace',
    btnTg: 'Telegram',
    descPS: 'Фриланс платформа с авторизацией, лентой заказов и чатом.',
    descLand: 'Сайт для бизнеса с адаптивным дизайном.',
    descPort: 'Этот сайт — моё портфолио.',
    live: 'Live сайт',
    ctTitle: 'Готов к работе',
    ctSub: 'Напишите мне — отвечу быстро!',
  },

  en: {
    title: 'Hi, I\'m <span style="color:#f97316">Zhanuzak</span> 👋',
    'about-text': 'I am a frontend developer creating modern websites.',
    navAbout: 'About',
    navSkills: 'Skills',
    navProjects: 'Projects',
    navContact: 'Contact',
    secAbout: 'About me',
    secSkills: 'Skills',
    secProjects: 'Projects',
    secContact: 'Contact',
    btnPS: 'ProfiSpace',
    btnTg: 'Telegram',
    descPS: 'Freelance platform with auth, job feed and chat.',
    descLand: 'Business website with responsive design.',
    descPort: 'This site — my portfolio.',
    live: 'Live site',
    ctTitle: 'Open to work',
    ctSub: 'Message me — I reply fast!',
  },

  kz: {
    title: 'Сәлем, мен <span style="color:#f97316">Zhanuzak</span> 👋',
    'about-text': 'Мен заманауи сайттар жасайтын frontend әзірлеушімін.',
    navAbout: 'Мен туралы',
    navSkills: 'Дағдылар',
    navProjects: 'Жобалар',
    navContact: 'Байланыс',
    secAbout: 'Мен туралы',
    secSkills: 'Дағдылар',
    secProjects: 'Жобалар',
    secContact: 'Байланыс',
    btnPS: 'ProfiSpace',
    btnTg: 'Telegram',
    descPS: 'Авторизациямен, тапсырыс лентасымен және чатпен фриланс платформасы.',
    descLand: 'Адаптивті дизайны бар бизнес сайты.',
    descPort: 'Бұл сайт — менің портфолиом.',
    live: 'Live сайт',
    ctTitle: 'Жұмысқа дайынмын',
    ctSub: 'Маған жазыңыз — жылдам жауап беремін!',
  }

};


// Функция смены языка
// lang — строка: 'ru', 'en' или 'kz'
function setLang(lang) {

  // Берём нужный объект перевода по коду языка
  const d = translations[lang];

  // Меняем HTML заголовка (используем innerHTML, потому что там есть тег <span>)
  document.getElementById('title').innerHTML = d['title'];

  // Меняем текст описания (textContent — просто текст, без HTML тегов)
  document.getElementById('about-text').textContent = d['about-text'];

  // Находим все элементы с атрибутом data-t и меняем их текст
  // data-t="navAbout" — значит ставим текст из d['navAbout']
  document.querySelectorAll('[data-t]').forEach(function(el) {
    var key = el.getAttribute('data-t'); // Читаем ключ перевода
    if (d[key]) el.textContent = d[key]; // Если перевод есть — ставим
  });

  // Подсвечиваем активную кнопку языка
  // Сравниваем текст кнопки (ru/en/kz) с выбранным языком
  document.querySelectorAll('.lang-btns button').forEach(function(btn) {
    var isActive = btn.textContent.toLowerCase() === lang;
    btn.classList.toggle('active', isActive); // Добавляем/убираем класс active
  });

}


// Функция открытия Telegram в новой вкладке
function contact() {
  window.open('https://t.me/zhanuzak', '_blank');
}
