function contact() {
alert("Telegram: @your_username");
}

// Language switch
function setLang(lang) {
const title = document.getElementById("title");
const about = document.getElementById("about-text");

if (lang === "ru") {
title.innerText = "Привет, я Zhanuzak 👋";
about.innerText = "Я frontend разработчик и создаю современные сайты.";
}

if (lang === "en") {
title.innerText = "Hi, I'm Zhanuzak 👋";
about.innerText = "I am a frontend developer creating modern websites.";
}

if (lang === "kz") {
title.innerText = "Сәлем, мен Zhanuzak 👋";
about.innerText = "Мен заманауи сайттар жасайтын frontend әзірлеушімін.";
}
}

// Scroll animation
const sections = document.querySelectorAll('.fade-in');

const observer = new IntersectionObserver(entries => {
entries.forEach(entry => {
if (entry.isIntersecting) {
entry.target.classList.add('visible');
}
});
}, { threshold: 0.2 });

sections.forEach(section => observer.observe(section));