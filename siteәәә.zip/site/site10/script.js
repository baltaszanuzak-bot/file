// Navbar background change on scroll
window.addEventListener("scroll", function () {
    const nav = document.querySelector(".navbar");

    if (window.scrollY > 50) {
        nav.style.background = "rgba(0,0,0,0.95)";
    } else {
        nav.style.background = "rgba(0,0,0,0.8)";
    }
});

// ---- AVATAR ----
function getInitials(name) {
    return name.trim().charAt(0).toUpperCase();
}

function checkAuth() {
    const user = localStorage.getItem('cody_user');
    if (user) {
        document.getElementById('loginLink').style.display = 'none';
        document.getElementById('avatarWrap').style.display = 'block';
        document.getElementById('avatarCircle').textContent = getInitials(user);
        document.getElementById('dropUsername').textContent = user;
    } else {
        document.getElementById('loginLink').style.display = 'inline';
        document.getElementById('avatarWrap').style.display = 'none';
    }
}

function toggleDropdown() {
    document.getElementById('avatarDropdown').classList.toggle('open');
}

function doLogout() {
    localStorage.removeItem('cody_user');
    checkAuth();
    document.getElementById('avatarDropdown').classList.remove('open');
}

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
    const wrap = document.getElementById('avatarWrap');
    if (wrap && !wrap.contains(e.target)) {
        document.getElementById('avatarDropdown').classList.remove('open');
    }
});

checkAuth();

// ---- TRANSLATIONS ----
const T = {
    en:{
        nav_login:"Login", nav_about:"About", nav_foundation:"Foundation", nav_learning:"Learning",
        hero_title:"Cody Tech",
        hero_desc:"Cody Tech is a modern technology platform focused on programming languages, software development, and building a strong developer ecosystem.",
        btn_start:"Start Learning",
        about_title:"About",
        about_desc:"Our mission is to create a space where developers grow — from fundamentals to advanced engineering.",
        found_title:"Foundation",
        card1_title:"Goal: Build the core infrastructure",
        card1_desc:"Launch of the Cody Tech platform. Structured programming fundamentals",
        card2_title:"Core language tracks:",
        card2_desc:"JavaScript, HTML, CSS. Hands-on coding challenges. Documentation & real-world examples",
        card3_title:"Ecosystem",
        card3_desc:"Goal: Build a developer environment. Open-source projects. Collaboration tools. Version control. Community-driven development.",
        ready_title:"Ready to Start?",
        footer_txt:"Web Development Courses (HTML, CSS, JavaScript).",
        drop_role:"Student", drop_profile:"My Profile", drop_courses:"My Courses",
        drop_settings:"Settings", drop_logout:"Logout",
        back:"Back to Courses", title:"Swift — Apple's Modern Programming Language",
        hero_desc:"Swift is a powerful and intuitive programming language for iOS, macOS, watchOS, and tvOS. Developed by Apple, it's designed to be safe, fast, and expressive.",
        b1:"iOS & macOS", b2:"Safe & Fast", b3:"Modern Syntax",
        nav_label:"Topics", nav_intro:"What is Swift?", nav_syntax:"Basic Syntax",
        nav_optionals:"Optionals", nav_fns:"Functions & Closures", nav_structs:"Structs & Classes",
        nav_protocols:"Protocols & Extensions", nav_async:"Async/Await", nav_practice:"Project: Todo App",
        s1_title:"What is Swift?", s1_intro:"Swift is Apple's modern programming language introduced in 2014. It's designed to be safe, fast, and expressive, with features like optionals, type inference, and powerful functional programming capabilities. Swift is used for developing iOS, macOS, watchOS, and tvOS applications.",
        c1_t:"📱 Apple Ecosystem", c1_d:"Primary language for all Apple platforms: iOS, iPadOS, macOS, watchOS, tvOS.",
        c2_t:"🛡️ Safety First", c2_d:"Optionals eliminate null pointer crashes. Memory is managed automatically with ARC.",
        c3_t:"⚡ Performance", c3_d:"Compiles to native code using LLVM, with performance comparable to C++.",
        s2_title:"Basic Syntax", s2_intro:"Swift syntax is clean and expressive. No semicolons needed, with strong type inference and modern features.",
        s3_title:"Optionals — Safe Handling of Missing Values", s3_intro:"Optionals represent values that might be nil (absent). Swift forces you to handle nil safely, eliminating null pointer crashes.",
        s4_title:"Functions & Closures", s4_intro:"Functions are first-class citizens. Closures are self-contained blocks of functionality that can be passed around.",
        s5_title:"Structs & Classes", s5_intro:"Swift uses structs (value types) and classes (reference types). Structs are preferred for most data modeling.",
        s6_title:"Protocols & Extensions", s6_intro:"Protocols define blueprints of methods and properties. Extensions add functionality to existing types.",
        s7_title:"Async/Await — Modern Concurrency", s7_intro:"Swift 5.5 introduced structured concurrency with async/await, making asynchronous code easier to write and understand.",
        tip_async:"Use `@State` and `@ObservableObject` with async/await. Combine framework provides publishers for reactive programming.",
        s8_title:"🛠 Project: Todo App (SwiftUI)", s8_intro:"Build a simple todo list app using SwiftUI with persistent storage.",
        challenge:"Add due dates and priority levels. Implement notifications for overdue tasks. Add categories/tags for todos. Sync with iCloud using CloudKit.",
        footer_txt:"© 2026 Cody Tech — Swift Course", prev_btn:"← Kotlin", next_btn:"Next: Rust →",
        back:"Back to Courses", title:"HTML — HyperText Markup Language",
        hero_desc:"The skeleton of every webpage. Learn how to structure content using tags, elements and attributes — the foundation of all web development.",
        b1:"Beginner Friendly",b2:"Web Foundation",b3:"Markup Language",
        nav_label:"Topics",nav_intro:"What is HTML?",nav_structure:"Document Structure",
        nav_tags:"Essential Tags",nav_attrs:"Attributes",nav_forms:"Forms & Inputs",
        nav_semantic:"Semantic HTML",nav_links:"Links & Images",nav_practice:"First Project",
        s1_title:"What is HTML?",s1_intro:"HTML stands for HyperText Markup Language. It defines the structure and meaning of web content using elements (tags). Every website you visit is built on HTML.",
        c1_t:"📄 Markup Language",c1_d:"HTML uses tags to annotate text and define its role: heading, paragraph, link, image, etc.",
        c2_t:"🌐 Rendered by Browsers",c2_d:"Browsers read HTML and display it visually. They hide the tags and show only the content.",
        c3_t:"🧱 Foundation Layer",c3_d:"HTML is the base layer. CSS adds styling, JavaScript adds behaviour — but HTML is always first.",
        s2_title:"Document Structure",s2_intro:"Every HTML file follows the same skeleton. Here is the minimal template that every page starts with:",
        step1_t:"<!DOCTYPE html>",step1_d:"Tells the browser this is an HTML5 document. Always the very first line.",
        step2_t:"<head>",step2_d:"Contains invisible metadata: character set, page title, links to stylesheets and scripts.",
        step3_t:"<body>",step3_d:"Everything visible on the page goes here — text, images, buttons, menus.",
        s3_title:"Essential Tags",s3_intro:"These are the most commonly used HTML tags. Memorize these and you can build any basic page.",
        th_tag:"Tag",th_use:"Purpose",th_ex:"Example",
        td1:"Headings, h1=largest",td2:"Paragraph of text",td3:"Hyperlink",td4:"Image",td5:"Unordered/Ordered list",td6:"Generic block container",td7:"Inline container",td8:"Line break",td9:"Bold / important",td10:"Italic / emphasis",td11:"Data table",td12:"Clickable button",
        s4_title:"Attributes",s4_intro:"Attributes provide extra information about elements. They are written inside the opening tag as name=\"value\" pairs.",
        tip_attr:'The id must be unique on the page. The class can be reused on many elements and is the main way CSS targets elements.',
        s5_title:"Forms & Inputs",s5_intro:"Forms collect user input — login data, search queries, signup info. Every interactive website uses them.",
        ft1:"Single-line text input.",ft2:"Hides typed characters.",ft3:"Validates email format automatically.",ft4:"On/off toggle box.",ft5:"Pick one from a group.",ft6:"Multi-line text input.",
        s6_title:"Semantic HTML",s6_intro:"Semantic tags describe the meaning of content, not just its appearance. They improve accessibility and SEO.",
        tip_semantic:"Use <div> for styling/layout purposes only. Use semantic tags like <header>, <main>, <footer>, <article> when the content has a clear meaning.",
        s7_title:"Links & Images",s7_intro:"Hyperlinks connect pages together and images make the web visual. These two tags are used on every site.",
        s8_title:"🛠 First Project: Personal Card",s8_intro:"Put it all together! Build your first HTML page — a personal profile card using everything you've learned.",
        challenge:"Add a <form> at the bottom that lets visitors send a message. Use inputs for name, email and a <textarea> for the message.",
        footer_txt:"© 2026 Cody Tech — HTML Course",next_btn:"Next: CSS →",
        back:"Back to Courses",title:"CSS — Cascading Style Sheets",
        hero_desc:"The design layer of the web. Control colors, fonts, layouts, animations and make any HTML page look stunning.",
        b1:"Visual Design",b2:"Layouts & Animations",b3:"Beginner Friendly",
        nav_label:"Topics",nav_intro:"What is CSS?",nav_sel:"Selectors",nav_box:"Box Model",
        nav_colors:"Colors & Fonts",nav_flex:"Flexbox",nav_grid:"CSS Grid",
        nav_anim:"Animations",nav_resp:"Responsive Design",nav_practice:"Project: Style It!",
        s1_title:"What is CSS?",s1_intro:"CSS — Cascading Style Sheets — is the language used to style HTML elements. It controls colors, fonts, spacing, layouts and animations.",
        c1_t:"🎨 Styling",c1_d:"Colors, fonts, sizes, borders — every visual detail is controlled by CSS.",
        c2_t:"📐 Layout",c2_d:"Flexbox and Grid let you build any layout — from simple rows to complex dashboards.",
        c3_t:"✨ Animation",c3_d:"Transitions and keyframe animations bring your pages to life without JavaScript.",
        s2_title:"Selectors",s2_intro:"Selectors are how CSS targets specific HTML elements. Choosing the right selector is the key to clean styles.",
        tip_sel:"Prefer classes over IDs for styling. IDs are harder to override due to higher specificity.",
        s3_title:"The Box Model",s3_intro:"Every HTML element is a rectangular box. The box model describes the layers: padding, border, and margin.",
        s4_title:"Colors & Typography",s4_intro:"CSS supports multiple color formats and rich font control. Google Fonts gives you thousands of free typefaces.",
        s5_title:"Flexbox",s5_intro:"Flexbox is a one-dimensional layout system. It arranges items in a row or column with powerful alignment control.",
        s6_title:"CSS Grid",s6_intro:"CSS Grid is a two-dimensional layout system — perfect for building complex page layouts with rows AND columns.",
        s7_title:"Transitions & Animations",s7_intro:"CSS animations bring pages to life. Transitions handle simple state changes; @keyframes handle complex sequences.",
        s8_title:"Responsive Design",s8_intro:"Media queries let you apply different styles based on screen size — making your site look great on any device.",
        tip_resp:"Start your CSS for small screens and use min-width media queries to add styles for larger screens. This is called 'Mobile First'.",
        s9_title:"🎨 Project: Style the Profile Card",s9_intro:"Take the HTML profile card from the previous lesson and make it look great with CSS.",
        footer_txt:"© 2026 Cody Tech — CSS Course",prev_btn:"← HTML",next_btn:"Next: JavaScript →",
        back:"Back to Courses",title:"JavaScript — The Language of the Web",
        hero_desc:"Make web pages interactive and dynamic. From DOM manipulation to APIs, JavaScript powers everything modern on the web.",
        b1:"Interactive Pages",b2:"Most Used Language",b3:"Frontend & Backend",
        nav_label:"Topics",nav_intro:"What is JS?",nav_vars:"Variables",nav_types:"Data Types",
        nav_fns:"Functions",nav_cond:"Conditionals",nav_loops:"Loops",
        nav_arr:"Arrays & Objects",nav_dom:"DOM & Events",nav_practice:"Project: Counter",
        s1_title_js:"What is JavaScript?",s1_intro_js:"JavaScript is the programming language of the web. It runs in every browser and makes HTML pages interactive.",
        c1_t_js:"🖱 Interactivity",c1_d_js:"Respond to user clicks, keyboard input, form submissions and mouse events.",
        c2_t_js:"🌐 DOM Control",c2_d_js:"Read and modify HTML and CSS on the fly — add elements, change styles.",
        c3_t_js:"🔗 APIs",c3_d_js:"Fetch data from servers, work with JSON, connect to third-party services.",
        c4_t_js:"⚙️ Server-side",c4_d_js:"With Node.js, JavaScript runs on servers too — full-stack in one language.",
        s2_title_js:"Variables",s2_intro_js:"Variables store data. JavaScript has three ways to declare them.",
        tip_vars_js:"Use const by default. Switch to let only when you need to reassign. Never use var in modern code.",
        s3_title_js:"Data Types",s3_intro_js:"JavaScript has several built-in types. Understanding them prevents common bugs.",
        th_type_js:"Type",th_ex_js:"Example",th_note_js:"Note",
        type1_js:"Text. Use template literals for interpolation.",type2_js:"All numbers (int and float) are the same type.",
        type3_js:"Yes/No, on/off values.",type4_js:"Ordered list of values.",type5_js:"Key-value pairs.",
        type6_js:"Intentionally empty value.",type7_js:"Variable declared but not assigned.",
        s4_title_js:"Functions",s4_intro_js:"Functions are reusable blocks of code. Arrow functions are the modern standard.",
        s5_title_js:"Conditionals",s5_intro_js:"Conditionals let your code make decisions. The if/else statement is the foundation of program logic.",
        s6_title_js:"Loops",s6_intro_js:"Loops repeat code. for and forEach are the ones you'll use most.",
        s7_title_js:"Arrays & Objects",s7_intro_js:"Arrays store ordered lists; objects store named properties. Together they model any real-world data.",
        s8_title_js:"DOM & Events",s8_intro_js:"The DOM is JavaScript's view of the HTML page. You can read, change it and react to user events.",
        s9_title_js:"🛠 Project: Interactive Counter",s9_intro_js:"Build a click counter that combines HTML, CSS and JavaScript — your first fully interactive component!",
        challenge_js:"Make the counter color change: red when negative, green when positive, white at zero.",
        footer_txt_js:"© 2026 Cody Tech — JavaScript Course",prev_btn_js:"← CSS",next_btn_js:"More Courses →",
    },
    ru:{
        nav_login:"Войти", nav_about:"О нас", nav_foundation:"Основы", nav_learning:"Обучение",
        hero_title:"Cody Tech",
        hero_desc:"Cody Tech — современная технологическая платформа, ориентированная на языки программирования, разработку ПО и создание сильной экосистемы разработчиков.",
        btn_start:"Начать обучение",
        about_title:"О нас",
        about_desc:"Наша миссия — создать пространство, где разработчики растут от основ до продвинутой инженерии.",
        found_title:"Основы",
        card1_title:"Цель: создать базовую инфраструктуру",
        card1_desc:"Запуск платформы Cody Tech. Структурированные основы программирования",
        card2_title:"Основные языковые треки:",
        card2_desc:"JavaScript, HTML, CSS. Практические задачи. Документация и реальные примеры",
        card3_title:"Экосистема",
        card3_desc:"Цель: создать среду разработки. Open-source проекты. Инструменты совместной работы. Контроль версий.",
        ready_title:"Готовы начать?",
        footer_txt:"Курсы веб-разработки (HTML, CSS, JavaScript).",
        drop_role:"Студент", drop_profile:"Мой профиль", drop_courses:"Мои курсы",
        drop_settings:"Настройки", drop_logout:"Выйти",
        back:"Назад к курсам", title:"Swift — Современный язык программирования Apple",
        hero_desc:"Swift — мощный и интуитивный язык программирования для iOS, macOS, watchOS и tvOS. Разработан Apple для безопасности, скорости и выразительности.",
        b1:"iOS & macOS", b2:"Безопасный", b3:"Современный синтаксис",
        nav_label:"Темы", nav_intro:"Что такое Swift?", nav_syntax:"Синтаксис",
        nav_optionals:"Опционалы", nav_fns:"Функции и замыкания", nav_structs:"Структуры и классы",
        nav_protocols:"Протоколы и расширения", nav_async:"Async/Await", nav_practice:"Проект: Список дел",
        s1_title:"Что такое Swift?", s1_intro:"Swift — современный язык программирования Apple, представленный в 2014 году. Он безопасен, быстр и выразителен.",
        c1_t:"📱 Экосистема Apple", c1_d:"Основной язык для всех платформ Apple: iOS, iPadOS, macOS, watchOS, tvOS.",
        c2_t:"🛡️ Безопасность", c2_d:"Опционалы устраняют ошибки нулевых указателей. Память управляется автоматически с помощью ARC.",
        c3_t:"⚡ Производительность", c3_d:"Компилируется в нативный код с помощью LLVM, производительность сравнима с C++.",
        s2_title:"Базовый синтаксис", s2_intro:"Синтаксис Swift чистый и выразительный. Точки с запятой не нужны, сильный вывод типов.",
        s3_title:"Опционалы", s3_intro:"Опционалы представляют значения, которые могут отсутствовать (nil). Swift заставляет безопасно обрабатывать nil.",
        s4_title:"Функции и замыкания", s4_intro:"Функции — объекты первого класса. Замыкания — самодостаточные блоки функциональности.",
        s5_title:"Структуры и классы", s5_intro:"Swift использует структуры (типы-значения) и классы (ссылочные типы). Структуры предпочтительнее.",
        s6_title:"Протоколы и расширения", s6_intro:"Протоколы определяют требования к методам и свойствам. Расширения добавляют функциональность существующим типам.",
        s7_title:"Async/Await — Современная асинхронность", s7_intro:"Swift 5.5 ввел структурированную асинхронность с async/await, делая асинхронный код легче писать.",
        tip_async:"Используйте @State и @ObservableObject с async/await. Фреймворк Combine предоставляет publishers для реактивного программирования.",
        s8_title:"🛠 Проект: Список дел (SwiftUI)", s8_intro:"Создайте простое приложение списка дел с использованием SwiftUI с постоянным хранением.",
        challenge:"Добавьте даты, уровни приоритета. Реализуйте уведомления для просроченных задач. Добавьте категории/теги для дел. Синхронизируйте с iCloud с помощью CloudKit.",
        footer_txt:"© 2026 Cody Tech — Курс Swift", prev_btn:"← Kotlin", next_btn:"Далее: Rust →",
        back:"Назад к курсам", title:"HTML — Язык разметки гипертекста",
        hero_desc:"Скелет каждой веб-страницы. Изучите структурирование контента с помощью тегов, элементов и атрибутов — основа всей веб-разработки.",
        b1:"Для начинающих",b2:"Основа веба",b3:"Язык разметки",
        nav_label:"Темы",nav_intro:"Что такое HTML?",nav_structure:"Структура документа",
        nav_tags:"Основные теги",nav_attrs:"Атрибуты",nav_forms:"Формы и поля",
        nav_semantic:"Семантический HTML",nav_links:"Ссылки и изображения",nav_practice:"Первый проект",
        s1_title:"Что такое HTML?",s1_intro:"HTML — HyperText Markup Language. Определяет структуру веб-контента с помощью элементов (тегов). Каждый сайт построен на HTML.",
        c1_t:"📄 Язык разметки",c1_d:"HTML использует теги для обозначения роли текста: заголовок, абзац, ссылка, изображение.",
        c2_t:"🌐 Рендеринг браузером",c2_d:"Браузеры читают HTML и отображают его визуально, скрывая теги.",
        c3_t:"🧱 Базовый слой",c3_d:"HTML — это основа. CSS добавляет стили, JS — поведение. HTML всегда первый.",
        s2_title:"Структура документа",s2_intro:"Каждый HTML-файл следует одному шаблону. Вот минимальная структура:",
        step1_t:"<!DOCTYPE html>",step1_d:"Сообщает браузеру, что это HTML5. Всегда первая строка.",
        step2_t:"<head>",step2_d:"Содержит метаданные: кодировку, заголовок страницы, ссылки на стили и скрипты.",
        step3_t:"<body>",step3_d:"Всё видимое на странице — текст, изображения, кнопки, меню.",
        s3_title:"Основные теги",s3_intro:"Самые часто используемые HTML-теги. Запомните их и сможете создать любую базовую страницу.",
        th_tag:"Тег",th_use:"Назначение",th_ex:"Пример",
        td1:"Заголовки, h1=самый крупный",td2:"Абзац текста",td3:"Гиперссылка",td4:"Изображение",td5:"Маркированный/нумерованный список",td6:"Блочный контейнер",td7:"Строчный контейнер",td8:"Перенос строки",td9:"Жирный/важный",td10:"Курсив/акцент",td11:"Таблица данных",td12:"Кнопка",
        s4_title:"Атрибуты",s4_intro:"Атрибуты дают дополнительную информацию об элементах. Пишутся в открывающем теге как имя=\"значение\".",
        tip_attr:"id должен быть уникальным на странице. class можно переиспользовать и именно через него CSS стилизует элементы.",
        s5_title:"Формы и поля ввода",s5_intro:"Формы собирают данные от пользователя — логин, поиск, регистрация.",
        ft1:"Однострочный текстовый ввод.",ft2:"Скрывает введённые символы.",ft3:"Автоматически проверяет формат email.",ft4:"Чекбокс вкл/выкл.",ft5:"Выбор одного из нескольких.",ft6:"Многострочный ввод.",
        s6_title:"Семантический HTML",s6_intro:"Семантические теги описывают смысл контента. Улучшают доступность и SEO.",
        tip_semantic:"Используйте <div> только для стилизации. Используйте <header>, <main>, <footer>, <article> когда у контента есть смысловое значение.",
        s7_title:"Ссылки и изображения",s7_intro:"Гиперссылки связывают страницы, изображения делают веб визуальным.",
        s8_title:"🛠 Первый проект: Карточка профиля",s8_intro:"Соберите всё вместе! Создайте свою первую HTML-страницу — карточку профиля.",
        challenge:"Добавьте <form> внизу с полями имени, email и <textarea> для сообщения.",
        footer_txt:"© 2026 Cody Tech — Курс HTML",next_btn:"Далее: CSS →",
        back:"Назад к курсам",title:"CSS — Каскадные таблицы стилей",
        hero_desc:"Слой дизайна веба. Управляйте цветами, шрифтами, макетами и анимациями.",
        b1:"Визуальный дизайн",b2:"Макеты и анимации",b3:"Для начинающих",
        nav_label:"Темы",nav_intro:"Что такое CSS?",nav_sel:"Селекторы",nav_box:"Блочная модель",
        nav_colors:"Цвета и шрифты",nav_flex:"Flexbox",nav_grid:"CSS Grid",
        nav_anim:"Анимации",nav_resp:"Адаптивность",nav_practice:"Проект: Стилизуй!",
        s1_title:"Что такое CSS?",s1_intro:"CSS — Cascading Style Sheets — язык для стилизации HTML. Управляет цветами, шрифтами, отступами, макетами и анимациями.",
        c1_t:"🎨 Стилизация",c1_d:"Цвета, шрифты, размеры, границы — всё визуальное управляется CSS.",
        c2_t:"📐 Макеты",c2_d:"Flexbox и Grid позволяют строить любые макеты от простых строк до сложных дашбордов.",
        c3_t:"✨ Анимация",c3_d:"Transitions и @keyframes оживляют страницы без JavaScript.",
        s2_title:"Селекторы",s2_intro:"Селекторы указывают, какие HTML-элементы стилизовать.",
        tip_sel:"Предпочитайте классы вместо ID для стилизации. ID сложнее переопределять из-за высокой специфичности.",
        s3_title:"Блочная модель",s3_intro:"Каждый HTML-элемент — прямоугольный блок. Блочная модель описывает слои: padding, border и margin.",
        s4_title:"Цвета и типографика",s4_intro:"CSS поддерживает несколько форматов цветов и богатый контроль шрифтов.",
        s5_title:"Flexbox",s5_intro:"Flexbox — одномерная система макетов. Выстраивает элементы в строку или столбец.",
        s6_title:"CSS Grid",s6_intro:"CSS Grid — двумерная система макетов. Идеально для сложных страниц с рядами и колонками.",
        s7_title:"Переходы и анимации",s7_intro:"CSS-анимации оживляют страницы. Transitions — простые переходы, @keyframes — сложные последовательности.",
        s8_title:"Адаптивный дизайн",s8_intro:"Media queries применяют разные стили в зависимости от размера экрана.",
        tip_resp:"Начинайте CSS для маленьких экранов и расширяйте через min-width. Это называется 'Mobile First'.",
        s9_title:"🎨 Проект: Стилизуй карточку профиля",s9_intro:"Возьми HTML-карточку из прошлого урока и сделай её красивой с помощью CSS.",
        footer_txt:"© 2026 Cody Tech — Курс CSS",prev_btn:"← HTML",next_btn:"Далее: JavaScript →",
    },
    kz:{
        nav_login:"Кіру", nav_about:"Біз туралы", nav_foundation:"Негіздер", nav_learning:"Оқыту",
        hero_title:"Cody Tech",
        hero_desc:"Cody Tech — бағдарламалау тілдеріне, бағдарламалық жасақтамаға және әзірлеушілер экожүйесін дамытуға бағытталған заманауи технологиялық платформа.",
        btn_start:"Оқуды бастау",
        about_title:"Біз туралы",
        about_desc:"Біздің миссиямыз — әзірлеушілер негіздерден жоғары деңгейлі инженерияға дейін өсетін кеңістік жасау.",
        found_title:"Негіздер",
        card1_title:"Мақсат: негізгі инфрақұрылымды құру",
        card1_desc:"Cody Tech платформасын іске қосу. Бағдарламалаудың құрылымдалған негіздері",
        card2_title:"Негізгі тіл бағыттары:",
        card2_desc:"JavaScript, HTML, CSS. Практикалық тапсырмалар. Құжаттама және нақты мысалдар",
        card3_title:"Экожүйе",
        card3_desc:"Мақсат: әзірлеу ортасын құру. Ашық бастапқы жобалар. Ынтымақтастық құралдары.",
        ready_title:"Бастауға дайынсыз ба?",
        footer_txt:"Веб-әзірлеу курстары (HTML, CSS, JavaScript).",
        drop_role:"Студент", drop_profile:"Менің профилім", drop_courses:"Менің курстарым",
        drop_settings:"Баптаулар", drop_logout:"Шығу",
        back:"Курстарға оралу", title:"Swift — Apple-дің заманауи бағдарламалау тілі",
        hero_desc:"Swift — iOS, macOS, watchOS және tvOS үшін қуатты және интуитивті бағдарламалау тілі. Apple қауіпсіздік, жылдамдық және мәнерлілік үшін жасаған.",
        b1:"iOS & macOS", b2:"Қауіпсіз әрі жылдам", b3:"Заманауи синтаксис",
        nav_label:"Тақырыптар", nav_intro:"Swift дегеніміз не?", nav_syntax:"Синтаксис",
        nav_optionals:"Опционалдар", nav_fns:"Функциялар мен жабындылар", nav_structs:"Құрылымдар мен класстар",
        nav_protocols:"Протоколдар мен кеңейтулер", nav_async:"Async/Await", nav_practice:"Жоба: Істер тізімі",
        s1_title:"Swift дегеніміз не?", s1_intro:"Swift — 2014 жылы Apple ұсынған заманауи бағдарламалау тілі. Қауіпсіз, жылдам және мәнерлі.",
        c1_t:"📱 Apple экожүйесі", c1_d:"Барлық Apple платформалары үшін негізгі тіл: iOS, iPadOS, macOS, watchOS, tvOS.",
        c2_t:"🛡️ Қауіпсіздік", c2_d:"Опционалдар null көрсеткіш қателерін жояды. Жад ARC арқылы автоматты басқарылады.",
        c3_t:"⚡ Өнімділік", c3_d:"LLVM көмегімен нативті кодқа компиляцияланады, C++-мен салыстырмалы өнімділік.",
        s2_title:"Негізгі синтаксис", s2_intro:"Swift синтаксисі таза және мәнерлі. Нүктелі үтір қажет емес, күшті типті болжау.",
        s3_title:"Опционалдар", s3_intro:"Опционалдар жоқ болуы мүмкін мәндерді (nil) білдіреді. Swift nil-ді қауіпсіз өңдеуге мәжбүрлейді.",
        s4_title:"Функциялар мен жабындылар", s4_intro:"Функциялар — бірінші класс объектілері. Жабындылар — өздігінен жеткілікті функционалдық блоктар.",
        s5_title:"Құрылымдар мен класстар", s5_intro:"Swift құрылымдарды (мән типтері) және класстарды (ссылка типтері) пайдаланады. Құрылымдар көбінесе артықшылық беріледі.",
        s6_title:"Протоколдар мен кеңейтулер", s6_intro:"Протоколдар әдістер мен қасиеттердің үлгілерін анықтайды. Кеңейтулер бар типтерге функционалдық қосады.",
        s7_title:"Async/Await", s7_intro:"Swift 5.5 құрылымдалған конкуренттілікті async/await көмегімен енгізді, асинхронды кодты жазуды жеңілдетті.",
        tip_async:"Async/await көмегімен `@State` және `@ObservableObject` пайдаланыңыз. Combine фреймворкі реактивті бағдарламалау үшін издательдерді ұсынады.",
        s8_title:"🛠 Жоба: Істер тізімі қолданбасы", s8_intro:"SwiftUI көмегімен тұрақты сақтаумен қарапайым істер тізімі қолданбасын жасаңыз.",
        challenge:"Орындау мерзімдерін және приоритеттерді қосыңыз. Мерзім өткен тапсырмалар үшін хабарландыруларды іске асырыңыз. Санаттарды қосыңыз. CloudKit арқылы iCloud-қа синхрондаңыз.",
        footer_txt:"© 2026 Cody Tech — Swift курсы", prev_btn:"← Kotlin", next_btn:"Келесі: Rust →",
        back:"Курстарға оралу",title:"HTML — Гипермәтіндік белгілеу тілі",
        hero_desc:"Әр веб-беттің қаңқасы. Тегтер, элементтер және атрибуттар көмегімен контентті құрылымдауды үйреніңіз — барлық веб-әзірлеудің негізі.",
        b1:"Бастапқыларға арналған",b2:"Веб негізі",b3:"Белгілеу тілі",
        nav_label:"Тақырыптар",nav_intro:"HTML дегеніміз не?",nav_structure:"Құжат құрылымы",
        nav_tags:"Маңызды тегтер",nav_attrs:"Атрибуттар",nav_forms:"Формалар мен кірістер",
        nav_semantic:"Семантикалық HTML",nav_links:"Сілтемелер мен суреттер",nav_practice:"Бірінші жоба",
        s1_title:"HTML дегеніміз не?",s1_intro:"HTML — HyperText Markup Language. Элементтер (тегтер) көмегімен веб-контенттің құрылымын және мағынасын анықтайды. Сіз кірген әр сайт HTML-ға негізделген.",
        c1_t:"📄 Белгілеу тілі",c1_d:"HTML мәтінді белгілеу және рөлін анықтау үшін тегтерді пайдаланады: тақырып, абзац, сілтеме, сурет және т.б.",
        c2_t:"🌐 Браузерлермен рендерленеді",c2_d:"Браузерлер HTML-ды оқиды және визуалды түрде көрсетеді. Олар тегтерді жасырып, тек контентті көрсетеді.",
        c3_t:"🧱 Негізгі қабат",c3_d:"HTML — негізгі қабат. CSS стиль қосады, JavaScript мінез-құлық қосады — бірақ HTML әрқашан бірінші.",
        s2_title:"Құжат құрылымы",s2_intro:"Әр HTML файлы бірдей қаңқаны ұстанады. Міне, әр бет басталатын минималды үлгі:",
        step1_t:"<!DOCTYPE html>",step1_d:"Браузерге бұл HTML5 құжаты екенін айтады. Әрқашан бірінші жол.",
        step2_t:"<head>",step2_d:"Көрінбейтін метадеректерді қамтиды: таңбалар жиыны, бет тақырыбы, стильдер мен скрипттерге сілтемелер.",
        step3_t:"<body>",step3_d:"Бетте көрінетін барлық нәрсе осында — мәтін, суреттер, түймелер, мәзірлер.",
        s3_title:"Маңызды тегтер",s3_intro:"Бұл ең жиі қолданылатын HTML тегтері. Оларды есте сақтаңыз және кез келген базалық бетті жасай аласыз.",
        th_tag:"Тег",th_use:"Мақсаты",th_ex:"Мысал",
        td1:"Тақырыптар, h1=ең үлкен",td2:"Мәтін абзацы",td3:"Гиперсілтеме",td4:"Сурет",td5:"Реттелмеген/реттелген тізім",td6:"Жалпы блок контейнері",td7:"Кірістірілген контейнер",td8:"Жол үзілімі",td9:"Қалың / маңызды",td10:"Көлбеу / екпін",td11:"Деректер кестесі",td12:"Басылатын түйме",
        s4_title:"Атрибуттар",s4_intro:"Атрибуттар элементтер туралы қосымша ақпарат береді. Олар ашылатын тег ішінде name=\"value\" жұптары ретінде жазылады.",
        tip_attr:'id бетте бірегей болуы керек. class көп элементтерде қайта қолданылуы мүмкін және CSS элементтерді нысанаға алудың негізгі жолы.',
        s5_title:"Формалар мен кірістер",s5_intro:"Формалар пайдаланушы кірісін жинайды — кіру деректері, іздеу сұраулары, тіркеу ақпараты. Әр интерактивті сайт оларды пайдаланады.",
        ft1:"Бір жолдық мәтін кірісі.",ft2:"Терілген таңбаларды жасырады.",ft3:"Электрондық пошта пішімін автоматты түрде тексереді.",ft4:"Қосу/өшіру ауыстырғышы.",ft5:"Топтан бірін таңдау.",ft6:"Көп жолдық мәтін кірісі.",
        s6_title:"Семантикалық HTML",s6_intro:"Семантикалық тегтер контенттің мағынасын сипаттайды, тек көрінісін емес. Олар қолжетімділік пен SEO-ны жақсартады.",
        tip_semantic:"<div>-ті тек стильдеу/орналастыру мақсаттары үшін пайдаланыңыз. Контент анық мағынаға ие болғанда <header>, <main>, <footer>, <article> сияқты семантикалық тегтерді пайдаланыңыз.",
        s7_title:"Сілтемелер мен суреттер",s7_intro:"Гиперсілтемелер беттерді біріктіреді, суреттер вебті визуалды етеді. Бұл екі тег әр сайтта қолданылады.",
        s8_title:"🛠 Бірінші жоба: Жеке карта",s8_intro:"Барлығын біріктіріңіз! Сіз үйренгеннің бәрін пайдаланып алғашқы HTML бетіңізді жасаңыз — үйренгеннің бәрін пайдаланатын жеке профиль картасы.",
        challenge:"Төменде келушілер хабар жібере алатын <form> қосыңыз. Аты, электрондық пошта үшін кірістер және хабар үшін <textarea> пайдаланыңыз.",
        footer_txt:"© 2026 Cody Tech — HTML курсы",next_btn:"Келесі: CSS →",
        back:"Курстарға оралу",title:"CSS — Каскадты стиль кестелері",
        hero_desc:"Вебтің дизайн қабаты. Түстерді, қаріптерді, макеттер мен анимацияларды басқарыңыз.",
        b1:"Визуалды дизайн",b2:"Макеттер мен анимациялар",b3:"Жаңадайлар үшін",
        nav_label:"Тақырыптар",nav_intro:"CSS дегеніміз не?",nav_sel:"Селекторлар",nav_box:"Блок үлгісі",
        nav_colors:"Түстер мен қаріптер",nav_flex:"Flexbox",nav_grid:"CSS Grid",
        nav_anim:"Анимациялар",nav_resp:"Адаптивтілік",nav_practice:"Жоба: Стильдеңіз!",
        s1_title:"CSS дегеніміз не?",s1_intro:"CSS — Cascading Style Sheets — HTML элементтерін безендіру тілі. Түстер, қаріптер, бос орындар, макеттер мен анимацияларды басқарады.",
        c1_t:"🎨 Стильдеу",c1_d:"Түстер, қаріптер, өлшемдер, жиектер — барлық визуалды нәрсе CSS арқылы.",
        c2_t:"📐 Макеттер",c2_d:"Flexbox және Grid кез келген макетті жасауға мүмкіндік береді.",
        c3_t:"✨ Анимация",c3_d:"Transitions пен @keyframes беттерді JavaScript-сіз жандандырады.",
        s2_title:"Селекторлар",s2_intro:"Селекторлар CSS-тің қандай HTML элементтерін стильдейтінін анықтайды.",
        tip_sel:"Стильдеу үшін ID-дан гөрі класстарды қолданыңыз. ID-дың специфигі жоғары, қайта анықтау қиын.",
        s3_title:"Блок үлгісі",s3_intro:"Әр HTML элементі — тіктөртбұрышты блок. Блок үлгісі: padding, border және margin.",
        s4_title:"Түстер мен типография",s4_intro:"CSS бірнеше түс форматтарын және бай қаріп басқаруды қолдайды.",
        s5_title:"Flexbox",s5_intro:"Flexbox — бір өлшемді макет жүйесі. Элементтерді қатар немесе баған бойынша орналастырады.",
        s6_title:"CSS Grid",s6_intro:"CSS Grid — екі өлшемді макет жүйесі. Күрделі беттер үшін тамаша.",
        s7_title:"Өтулер мен анимациялар",s7_intro:"CSS анимациялары беттерді жандандырады.",
        s8_title:"Адаптивті дизайн",s8_intro:"Media queries экран өлшеміне байланысты әр түрлі стильдерді қолдануға мүмкіндік береді.",
        tip_resp:"Кіші экрандарға арналған CSS-тен бастаңыз, үлкен экрандар үшін min-width арқылы кеңейтіңіз.",
        s9_title:"🎨 Жоба: Профиль картасын стильдеңіз",s9_intro:"Алдыңғы сабақтағы HTML картасын CSS арқылы әдемі етіңіз.",
        footer_txt:"© 2026 Cody Tech — CSS Курсы",prev_btn:"← HTML",next_btn:"Келесі: JavaScript →",
    }
};
let lang='en';

function setLang(l,btn){
    lang=l;
    document.querySelectorAll('.ctrl-btn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const t=T[l];
    document.querySelectorAll('[data-i]').forEach(el=>{
        const k=el.getAttribute('data-i');
        if(t[k]!==undefined) el.textContent=t[k];
    });
}

let dark=true;
function toggleTheme(){
    dark=!dark;
    document.body.classList.toggle('light',!dark);
    document.getElementById('themeBtn').textContent=dark?'🌙':'☀️';
}

// Simple fade-in animation on scroll
const sections = document.querySelectorAll(".section");

const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = 1;
            entry.target.style.transform = "translateY(0)";
        }
    });
});

sections.forEach(section => {
    section.style.opacity = 0;
    section.style.transform = "translateY(50px)";
    section.style.transition = "all 0.8s ease";
    observer.observe(section);
});
const modal = document.getElementById("loginModal");
const openBtn = document.getElementById("openLogin");
const closeBtn = document.querySelector(".close");

// открыть окно
openBtn.onclick = () => {
    modal.style.display = "block";
};

// закрыть
closeBtn.onclick = () => {
    modal.style.display = "none";
};

// закрытие при клике вне окна
window.onclick = (e) => {
    if (e.target === modal) {
        modal.style.display = "none";
    }
};

// обработка входа
document.getElementById("loginForm")
.addEventListener("submit", function(e) {

    e.preventDefault();

    const login = document.getElementById("login").value;
    const pass = document.getElementById("password").value;

    // тестовый аккаунт
    if (login === "admin" && pass === "1234") {
        alert("Вход выполнен!");
        modal.style.display = "none";
    } else {
        alert("Неверный логин или пароль");
    }

});
